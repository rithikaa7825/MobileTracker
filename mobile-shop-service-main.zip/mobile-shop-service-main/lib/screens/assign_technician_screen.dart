import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/glow_button.dart';
import '../data/mock_database.dart';
import '../models/technician.dart';
import '../models/repair_ticket.dart';

class AssignTechnicianScreen extends StatefulWidget {
  final Technician? preSelectedTech;

  const AssignTechnicianScreen({super.key, this.preSelectedTech});

  @override
  State<AssignTechnicianScreen> createState() => _AssignTechnicianScreenState();
}

class _AssignTechnicianScreenState extends State<AssignTechnicianScreen> {
  Technician? _selectedTech;
  RepairTicket? _selectedTicket;

  @override
  void initState() {
    super.initState();
    _selectedTech = widget.preSelectedTech;
    MockDatabase.instance.addListener(_onDbChanged);
  }

  void _onDbChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    MockDatabase.instance.removeListener(_onDbChanged);
    super.dispose();
  }

  List<RepairTicket> get _unassignedTickets => MockDatabase.instance.tickets
      .where((t) =>
          t.status != 'Delivered' && t.status != 'Completed')
      .toList();

  void _confirmAssignment() {
    if (_selectedTech == null || _selectedTicket == null) return;
    MockDatabase.instance.assignTechnicianToTicket(
        _selectedTicket!.id, _selectedTech!.name);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          opacity: 0.18,
          color: Colors.black,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFF0D9488).withOpacity(0.3)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF0D9488).withOpacity(0.12),
                ),
                child: const Icon(Icons.check_circle_rounded,
                    color: Color(0xFF2DD4BF), size: 40),
              ),
              const SizedBox(height: 16),
              Text(
                'Technician Assigned!',
                style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                '${_selectedTech!.name} has been assigned to ticket ${_selectedTicket!.id} (${_selectedTicket!.brand} ${_selectedTicket!.model}).',
                textAlign: TextAlign.center,
                style: GoogleFonts.inter(
                    color: const Color(0xFF94A3B8),
                    fontSize: 13,
                    height: 1.5),
              ),
              const SizedBox(height: 24),
              GlowButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                text: 'Done',
                height: 46,
                gradientColors: const [
                  Color(0xFF0D9488),
                  Color(0xFF0F766E)
                ],
                shadowColor: const Color(0xFF0D9488),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final techs = MockDatabase.instance.technicians;
    final tickets = _unassignedTickets;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          Positioned(
            top: -60,
            left: -60,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF8B5CF6).withOpacity(0.07),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFF8B5CF6).withOpacity(0.07),
                      blurRadius: 100,
                      spreadRadius: 40),
                ],
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                  child: _buildHeader(),
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
                    physics: const BouncingScrollPhysics(),
                    children: [
                      // Step 1: Select Technician
                      _buildSectionHeader(
                          '1', 'Select Technician', Icons.person_search_rounded,
                          const Color(0xFF8B5CF6)),
                      const SizedBox(height: 14),
                      ...techs.map((tech) => _buildTechOption(tech)),
                      const SizedBox(height: 28),

                      // Step 2: Select Ticket
                      _buildSectionHeader(
                          '2', 'Select Repair Ticket', Icons.assignment_rounded,
                          const Color(0xFF0D9488)),
                      const SizedBox(height: 14),
                      tickets.isEmpty
                          ? GlassCard(
                              opacity: 0.06,
                              child: Row(
                                children: [
                                  const Icon(Icons.check_circle_outline_rounded,
                                      color: Colors.greenAccent, size: 20),
                                  const SizedBox(width: 12),
                                  Text(
                                    'All tickets are currently assigned!',
                                    style: GoogleFonts.inter(
                                        color: Colors.white70, fontSize: 13),
                                  ),
                                ],
                              ),
                            )
                          : Column(
                              children: tickets
                                  .map((t) => _buildTicketOption(t))
                                  .toList(),
                            ),
                      const SizedBox(height: 32),

                      // Assignment Summary
                      if (_selectedTech != null && _selectedTicket != null)
                        _buildAssignmentSummary(),

                      const SizedBox(height: 20),
                      GlowButton(
                        onPressed: (_selectedTech != null &&
                                _selectedTicket != null)
                            ? _confirmAssignment
                            : null,
                        text: 'Confirm Assignment',
                        icon: Icons.person_add_alt_1_rounded,
                        height: 54,
                        gradientColors: const [
                          Color(0xFF8B5CF6),
                          Color(0xFF6D28D9)
                        ],
                        shadowColor: const Color(0xFF8B5CF6),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white70, size: 18),
          ),
        ),
        const SizedBox(width: 14),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Assign Technician',
                style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold)),
            Text('Link a technician to a repair ticket',
                style:
                    GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 13)),
          ],
        ),
      ],
    ).animate().fade(duration: 400.ms).slideY(begin: -0.1);
  }

  Widget _buildSectionHeader(
      String step, String title, IconData icon, Color color) {
    return Row(
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.15),
            border: Border.all(color: color.withOpacity(0.4)),
          ),
          child: Center(
            child: Text(step,
                style: GoogleFonts.outfit(
                    color: color, fontSize: 13, fontWeight: FontWeight.bold)),
          ),
        ),
        const SizedBox(width: 10),
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 8),
        Text(title,
            style: GoogleFonts.outfit(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildTechOption(Technician tech) {
    final isSelected = _selectedTech?.id == tech.id;
    Color statusColor;
    switch (tech.status) {
      case 'Active':
        statusColor = const Color(0xFF0D9488);
        break;
      case 'Busy':
        statusColor = Colors.orangeAccent;
        break;
      default:
        statusColor = const Color(0xFF475569);
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: tech.status == 'Offline'
            ? null
            : () => setState(() => _selectedTech = tech),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: isSelected
                ? const Color(0xFF8B5CF6).withOpacity(0.1)
                : Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isSelected
                  ? const Color(0xFF8B5CF6).withOpacity(0.5)
                  : Colors.white.withOpacity(0.06),
              width: isSelected ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundImage: NetworkImage(tech.imageUrl),
                    foregroundColor: tech.status == 'Offline'
                        ? Colors.black.withOpacity(0.4)
                        : null,
                  ),
                  if (tech.status == 'Offline')
                    Positioned.fill(
                      child: ClipOval(
                        child: Container(color: Colors.black.withOpacity(0.5)),
                      ),
                    ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: statusColor,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: const Color(0xFF0F172A), width: 1.5),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tech.name,
                        style: GoogleFonts.outfit(
                            color: tech.status == 'Offline'
                                ? Colors.white38
                                : Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold)),
                    Text(
                      '${tech.role}  •  ${tech.activeJobs} active job${tech.activeJobs != 1 ? 's' : ''}',
                      style: GoogleFonts.inter(
                          color: const Color(0xFF64748B), fontSize: 11),
                    ),
                  ],
                ),
              ),
              if (tech.status == 'Offline')
                Text('Unavailable',
                    style: GoogleFonts.inter(
                        color: const Color(0xFF475569), fontSize: 11))
              else if (isSelected)
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF8B5CF6).withOpacity(0.2),
                  ),
                  child: const Icon(Icons.check_rounded,
                      color: Color(0xFF8B5CF6), size: 16),
                )
              else
                Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white12),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTicketOption(RepairTicket ticket) {
    final isSelected = _selectedTicket?.id == ticket.id;
    Color statusColor;
    switch (ticket.status) {
      case 'Pending':
        statusColor = Colors.cyanAccent;
        break;
      case 'In Progress':
        statusColor = const Color(0xFF8B5CF6);
        break;
      default:
        statusColor = Colors.grey;
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: () => setState(() => _selectedTicket = ticket),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: isSelected
                ? const Color(0xFF0D9488).withOpacity(0.08)
                : Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isSelected
                  ? const Color(0xFF0D9488).withOpacity(0.4)
                  : Colors.white.withOpacity(0.06),
              width: isSelected ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(ticket.id,
                            style: GoogleFonts.outfit(
                                color: statusColor,
                                fontSize: 11,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(ticket.status,
                              style: TextStyle(
                                  color: statusColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text('${ticket.brand} ${ticket.model}',
                        style: GoogleFonts.outfit(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold)),
                    Text(
                      '${ticket.customerName}  •  ${ticket.issue}',
                      style: GoogleFonts.inter(
                          color: const Color(0xFF64748B), fontSize: 11),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              if (isSelected)
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF0D9488).withOpacity(0.2),
                  ),
                  child: const Icon(Icons.check_rounded,
                      color: Color(0xFF0D9488), size: 16),
                )
              else
                Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white12),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAssignmentSummary() {
    return GlassCard(
      opacity: 0.08,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: const Color(0xFF8B5CF6).withOpacity(0.25)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.assignment_ind_rounded,
                  color: Color(0xFFA78BFA), size: 18),
              const SizedBox(width: 8),
              Text('Assignment Preview',
                  style: GoogleFonts.outfit(
                      color: const Color(0xFFA78BFA),
                      fontSize: 13,
                      fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 14),
          _buildSummaryRow(
              Icons.person_rounded, 'Technician', _selectedTech!.name),
          const SizedBox(height: 8),
          _buildSummaryRow(
              Icons.smartphone_rounded, 'Device',
              '${_selectedTicket!.brand} ${_selectedTicket!.model}'),
          const SizedBox(height: 8),
          _buildSummaryRow(Icons.confirmation_number_rounded, 'Ticket ID',
              _selectedTicket!.id),
          const SizedBox(height: 8),
          _buildSummaryRow(Icons.person_outline_rounded, 'Customer',
              _selectedTicket!.customerName),
        ],
      ),
    ).animate().fade(duration: 300.ms).scale(begin: const Offset(0.97, 0.97));
  }

  Widget _buildSummaryRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 14, color: const Color(0xFF64748B)),
        const SizedBox(width: 8),
        Text('$label:  ',
            style: GoogleFonts.inter(
                color: const Color(0xFF64748B), fontSize: 12)),
        Expanded(
          child: Text(value,
              style: GoogleFonts.inter(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600),
              overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }
}
