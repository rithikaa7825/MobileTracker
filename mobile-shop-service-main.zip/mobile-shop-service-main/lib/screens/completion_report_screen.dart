import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../data/mock_database.dart';
import '../models/technician.dart';

class CompletionReportScreen extends StatefulWidget {
  const CompletionReportScreen({super.key});

  @override
  State<CompletionReportScreen> createState() => _CompletionReportScreenState();
}

class _CompletionReportScreenState extends State<CompletionReportScreen> {
  String _selectedPeriod = 'This Week';
  final List<String> _periods = ['Today', 'This Week', 'This Month', 'All Time'];

  @override
  Widget build(BuildContext context) {
    final techs = MockDatabase.instance.technicians;
    final tickets = MockDatabase.instance.tickets;

    final completedTickets = tickets
        .where((t) => t.status == 'Completed' || t.status == 'Delivered')
        .toList();
    final inProgressTickets =
        tickets.where((t) => t.status == 'In Progress').toList();
    final pendingTickets =
        tickets.where((t) => t.status == 'Pending').toList();

    // Mock revenue based on completed tickets
    final revenue = completedTickets.length * 95 + 3200;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          Positioned(
            top: -50,
            right: -50,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.amberAccent.withOpacity(0.05),
                boxShadow: [
                  BoxShadow(
                      color: Colors.amberAccent.withOpacity(0.05),
                      blurRadius: 100,
                      spreadRadius: 40),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: -80,
            left: -80,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF8B5CF6).withOpacity(0.05),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFF8B5CF6).withOpacity(0.05),
                      blurRadius: 80,
                      spreadRadius: 30),
                ],
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                      child: _buildHeader(),
                    ),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
                        physics: const BouncingScrollPhysics(),
                        children: [
                          // Period selector
                          _buildPeriodSelector(),
                          const SizedBox(height: 20),

                          // Summary KPI cards
                          _buildKpiGrid(
                              completedTickets.length,
                              inProgressTickets.length,
                              pendingTickets.length,
                              revenue),
                          const SizedBox(height: 24),

                          // Ticket status distribution
                          _buildStatusDistribution(tickets.length,
                              completedTickets.length, inProgressTickets.length,
                              pendingTickets.length),
                          const SizedBox(height: 24),

                          // Weekly bar chart
                          _buildWeeklyChart(),
                          const SizedBox(height: 24),

                          // Per-technician leaderboard
                          Text('Technician Performance',
                              style: GoogleFonts.outfit(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold)),
                          const SizedBox(height: 14),
                          ...techs.asMap().entries.map(
                                (e) => Padding(
                                  padding: const EdgeInsets.only(bottom: 12),
                                  child: _buildTechReport(e.value, e.key + 1),
                                ),
                              ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white70, size: 18),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Completion Report',
                  style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold)),
              Text('Shop-wide performance analytics',
                  style: GoogleFonts.inter(
                      color: const Color(0xFF64748B), fontSize: 13)),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.amberAccent.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.amberAccent.withOpacity(0.2)),
          ),
          child: const Icon(Icons.bar_chart_rounded,
              color: Colors.amberAccent, size: 20),
        ),
      ],
    ).animate().fade(duration: 400.ms).slideY(begin: -0.1);
  }

  Widget _buildPeriodSelector() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: _periods.map((p) {
          final isSelected = _selectedPeriod == p;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () => setState(() => _selectedPeriod = p),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected
                      ? Colors.amberAccent.withOpacity(0.12)
                      : Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? Colors.amberAccent.withOpacity(0.4)
                        : Colors.white.withOpacity(0.08),
                  ),
                ),
                child: Text(p,
                    style: GoogleFonts.inter(
                        color: isSelected
                            ? Colors.amberAccent
                            : const Color(0xFF94A3B8),
                        fontSize: 12,
                        fontWeight: isSelected
                            ? FontWeight.bold
                            : FontWeight.normal)),
              ),
            ),
          );
        }).toList(),
      ),
    ).animate().fade(duration: 400.ms, delay: 100.ms);
  }

  Widget _buildKpiGrid(
      int completed, int inProgress, int pending, int revenue) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.45,
      children: [
        _buildKpiCard('Completed', '$completed', Icons.check_circle_rounded,
            Colors.greenAccent, '+${(completed * 0.12).toInt()}% vs prev'),
        _buildKpiCard('In Progress', '$inProgress',
            Icons.hourglass_top_rounded, const Color(0xFF8B5CF6),
            'Avg 2.1 days'),
        _buildKpiCard('Revenue', '\$$revenue', Icons.attach_money_rounded,
            Colors.amberAccent, '${_selectedPeriod.toLowerCase()}'),
        _buildKpiCard('Pending', '$pending', Icons.pending_actions_rounded,
            Colors.cyanAccent, 'Need assignment'),
      ],
    ).animate().fade(duration: 500.ms, delay: 120.ms);
  }

  Widget _buildKpiCard(String title, String value, IconData icon, Color color,
      String sub) {
    return GlassCard(
      padding: const EdgeInsets.all(14),
      opacity: 0.07,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(icon, color: color, size: 22),
              Container(
                  width: 6,
                  height: 6,
                  decoration:
                      BoxDecoration(shape: BoxShape.circle, color: color)),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value,
                  style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold)),
              Text(title,
                  style: GoogleFonts.inter(
                      color: const Color(0xFF64748B), fontSize: 11)),
              const SizedBox(height: 2),
              Text(sub,
                  style: GoogleFonts.inter(color: color, fontSize: 9,
                      fontWeight: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusDistribution(
      int total, int completed, int inProgress, int pending) {
    return GlassCard(
      opacity: 0.07,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Ticket Distribution',
              style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),

          // Segmented bar
          if (total > 0) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Row(
                children: [
                  _buildSegment(completed / total, Colors.greenAccent),
                  _buildSegment(inProgress / total, const Color(0xFF8B5CF6)),
                  _buildSegment(pending / total, Colors.cyanAccent),
                ],
              ),
            ),
            const SizedBox(height: 14),
          ],

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildLegendItem('Completed', completed, Colors.greenAccent),
              _buildLegendItem('In Progress', inProgress, const Color(0xFF8B5CF6)),
              _buildLegendItem('Pending', pending, Colors.cyanAccent),
            ],
          ),
        ],
      ),
    ).animate().fade(duration: 500.ms, delay: 160.ms);
  }

  Widget _buildSegment(double fraction, Color color) {
    final flex = (fraction * 100).toInt();
    return Expanded(
      flex: flex == 0 ? 1 : flex,
      child: Container(height: 12, color: fraction == 0 ? Colors.transparent : color),
    );
  }

  Widget _buildLegendItem(String label, int count, Color color) {
    return Column(
      children: [
        Row(
          children: [
            Container(
                width: 8,
                height: 8,
                decoration:
                    BoxDecoration(shape: BoxShape.circle, color: color)),
            const SizedBox(width: 5),
            Text(label,
                style: GoogleFonts.inter(
                    color: const Color(0xFF94A3B8), fontSize: 11)),
          ],
        ),
        const SizedBox(height: 3),
        Text('$count tickets',
            style: GoogleFonts.outfit(
                color: color, fontSize: 13, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildWeeklyChart() {
    final days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    // Simulated weekly data
    final data = [4, 7, 5, 9, 12, 3, 1];
    final maxVal = data.reduce((a, b) => a > b ? a : b).toDouble();

    return GlassCard(
      opacity: 0.07,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Repairs This Week',
                  style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold)),
              Text('41 total',
                  style: GoogleFonts.inter(
                      color: Colors.amberAccent,
                      fontSize: 12,
                      fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 110,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(7, (i) {
                final h = (data[i] / maxVal) * 90;
                final isToday = i == 4; // Friday mock
                return Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text('${data[i]}',
                        style: GoogleFonts.inter(
                            color: isToday
                                ? Colors.amberAccent
                                : const Color(0xFF64748B),
                            fontSize: 10,
                            fontWeight: isToday
                                ? FontWeight.bold
                                : FontWeight.normal)),
                    const SizedBox(height: 4),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 600),
                      curve: Curves.easeOut,
                      width: 18,
                      height: h,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: isToday
                              ? [
                                  Colors.amberAccent.withOpacity(0.6),
                                  Colors.amberAccent
                                ]
                              : [
                                  const Color(0xFF8B5CF6).withOpacity(0.3),
                                  const Color(0xFF8B5CF6).withOpacity(0.7),
                                ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(days[i],
                        style: GoogleFonts.inter(
                            color: isToday
                                ? Colors.amberAccent
                                : const Color(0xFF475569),
                            fontSize: 10,
                            fontWeight: isToday
                                ? FontWeight.bold
                                : FontWeight.normal)),
                  ],
                );
              }),
            ),
          ),
        ],
      ),
    ).animate().fade(duration: 500.ms, delay: 200.ms);
  }

  Widget _buildTechReport(Technician tech, int rank) {
    final assignedTickets =
        MockDatabase.instance.getTicketsForTechnician(tech.name);
    final done = assignedTickets
        .where((t) => t.status == 'Completed' || t.status == 'Delivered')
        .length;
    final total = assignedTickets.length;
    final rate = tech.successRate;

    Color rankColor;
    IconData rankIcon;
    switch (rank) {
      case 1:
        rankColor = Colors.amberAccent;
        rankIcon = Icons.emoji_events_rounded;
        break;
      case 2:
        rankColor = Colors.white70;
        rankIcon = Icons.military_tech_rounded;
        break;
      case 3:
        rankColor = const Color(0xFFCD7F32);
        rankIcon = Icons.military_tech_rounded;
        break;
      default:
        rankColor = const Color(0xFF475569);
        rankIcon = Icons.person_rounded;
    }

    return GlassCard(
      padding: const EdgeInsets.all(16),
      opacity: 0.07,
      child: Row(
        children: [
          // Rank badge
          Column(
            children: [
              Icon(rankIcon, color: rankColor, size: 20),
              Text('#$rank',
                  style: GoogleFonts.outfit(
                      color: rankColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(width: 14),

          // Avatar
          CircleAvatar(
            radius: 22,
            backgroundImage: NetworkImage(tech.imageUrl),
          ),
          const SizedBox(width: 12),

          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tech.name,
                    style: GoogleFonts.outfit(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold)),
                Text(tech.role,
                    style: GoogleFonts.inter(
                        color: const Color(0xFF64748B), fontSize: 11)),
                const SizedBox(height: 8),
                // Progress bar
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: rate,
                    backgroundColor: Colors.white.withOpacity(0.05),
                    color: rank == 1
                        ? Colors.amberAccent
                        : const Color(0xFF8B5CF6),
                    minHeight: 5,
                  ),
                ),
                const SizedBox(height: 5),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('${(rate * 100).toInt()}% success rate',
                        style: GoogleFonts.inter(
                            color: const Color(0xFF94A3B8), fontSize: 10)),
                    Text('$done/$total tickets done',
                        style: GoogleFonts.inter(
                            color: const Color(0xFF64748B), fontSize: 10)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),

          // Stats column
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('${tech.totalRepairs}',
                  style: GoogleFonts.outfit(
                      color: const Color(0xFFA78BFA),
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
              Text('repairs',
                  style: GoogleFonts.inter(
                      color: const Color(0xFF64748B), fontSize: 10)),
              const SizedBox(height: 4),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: _statusColor(tech.status).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(tech.status,
                    style: GoogleFonts.inter(
                        color: _statusColor(tech.status),
                        fontSize: 9,
                        fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ],
      ),
    )
        .animate(delay: (rank * 80).ms)
        .fade(duration: 400.ms)
        .slideY(begin: 0.05);
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Active':
        return const Color(0xFF0D9488);
      case 'Busy':
        return Colors.orangeAccent;
      default:
        return const Color(0xFF475569);
    }
  }
}
