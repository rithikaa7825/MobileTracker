import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../data/mock_database.dart';
import '../models/technician.dart';

class TechnicianWorkStatusScreen extends StatefulWidget {
  const TechnicianWorkStatusScreen({super.key});

  @override
  State<TechnicianWorkStatusScreen> createState() =>
      _TechnicianWorkStatusScreenState();
}

class _TechnicianWorkStatusScreenState
    extends State<TechnicianWorkStatusScreen> {
  @override
  void initState() {
    super.initState();
    MockDatabase.instance.addListener(_onDbChanged);
  }

  void _onDbChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    MockDatabase.instance.removeListener(_onDbChanged);
    super.dispose();
  }

  void _showStatusMenu(Technician tech) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 20,
                    backgroundImage: NetworkImage(tech.imageUrl),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tech.name,
                          style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      Text('Change duty status',
                          style: GoogleFonts.inter(
                              color: const Color(0xFF94A3B8), fontSize: 12)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Divider(color: Colors.white10),
              const SizedBox(height: 8),
              _buildStatusOption(tech, 'Active',
                  'Available for new assignments', const Color(0xFF0D9488),
                  Icons.radio_button_on),
              _buildStatusOption(tech, 'Busy',
                  'Currently handling jobs — limit new tasks', Colors.orangeAccent,
                  Icons.hourglass_top_rounded),
              _buildStatusOption(tech, 'Offline',
                  'Off duty or unavailable today', const Color(0xFF475569),
                  Icons.circle_outlined),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatusOption(Technician tech, String status, String subtitle,
      Color color, IconData icon) {
    final isCurrent = tech.status == status;
    return GestureDetector(
      onTap: () {
        MockDatabase.instance.updateTechnicianStatus(tech.id, status);
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${tech.name} marked as $status'),
            backgroundColor: color,
            behavior: SnackBarBehavior.floating,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isCurrent
              ? color.withOpacity(0.1)
              : Colors.white.withOpacity(0.03),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: isCurrent
                  ? color.withOpacity(0.4)
                  : Colors.white.withOpacity(0.06)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(status,
                      style: GoogleFonts.outfit(
                          color: isCurrent ? color : Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold)),
                  Text(subtitle,
                      style: GoogleFonts.inter(
                          color: const Color(0xFF64748B), fontSize: 11)),
                ],
              ),
            ),
            if (isCurrent)
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.check_rounded, color: color, size: 14),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final techs = MockDatabase.instance.technicians;
    final activeCount = techs.where((t) => t.status == 'Active').length;
    final busyCount = techs.where((t) => t.status == 'Busy').length;
    final offlineCount = techs.where((t) => t.status == 'Offline').length;
    final totalActive = techs.fold<int>(0, (sum, t) => sum + t.activeJobs);

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          Positioned(
            top: -50,
            right: -50,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF0D9488).withOpacity(0.07),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFF0D9488).withOpacity(0.07),
                      blurRadius: 100,
                      spreadRadius: 40),
                ],
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                      child: _buildHeader(),
                    ),

                    // Fleet overview bar
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                      child: _buildFleetOverview(
                          activeCount, busyCount, offlineCount, totalActive),
                    ),

                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
                      child: Text('Team Status Board',
                          style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                    ),

                    Expanded(
                      child: ListView.separated(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                        physics: const BouncingScrollPhysics(),
                        itemCount: techs.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, i) =>
                            _buildTechStatusCard(techs[i], i),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white70, size: 18),
          ),
        ),
        const SizedBox(width: 14),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Work Status',
                style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold)),
            Text('Monitor & control technician availability',
                style:
                    GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 13)),
          ],
        ),
      ],
    ).animate().fade(duration: 400.ms).slideY(begin: -0.1);
  }

  Widget _buildFleetOverview(
      int active, int busy, int offline, int totalActiveJobs) {
    return GlassCard(
      opacity: 0.07,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Fleet Overview',
              style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),

          // Gauge bar
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Row(
              children: [
                _buildBar(active, 4, const Color(0xFF0D9488)),
                _buildBar(busy, 4, Colors.orangeAccent),
                _buildBar(offline, 4, const Color(0xFF334155)),
              ],
            ),
          ),
          const SizedBox(height: 12),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildLegend('Active', active, const Color(0xFF0D9488)),
              _buildLegend('Busy', busy, Colors.orangeAccent),
              _buildLegend('Offline', offline, const Color(0xFF475569)),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('$totalActiveJobs',
                      style: GoogleFonts.outfit(
                          color: Colors.cyanAccent,
                          fontSize: 18,
                          fontWeight: FontWeight.bold)),
                  Text('Jobs in progress',
                      style: GoogleFonts.inter(
                          color: const Color(0xFF64748B), fontSize: 10)),
                ],
              ),
            ],
          ),
        ],
      ),
    ).animate().fade(duration: 500.ms, delay: 100.ms);
  }

  Widget _buildBar(int count, int total, Color color) {
    final flex = count == 0 ? 1 : count;
    return Expanded(
      flex: flex,
      child: Container(
        height: 10,
        color: count == 0 ? Colors.transparent : color,
      ),
    );
  }

  Widget _buildLegend(String label, int count, Color color) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color),
        ),
        const SizedBox(width: 5),
        Text('$count $label',
            style: GoogleFonts.inter(
                color: const Color(0xFF94A3B8), fontSize: 11)),
      ],
    );
  }

  Widget _buildTechStatusCard(Technician tech, int index) {
    Color statusColor;
    IconData statusIcon;
    String statusLabel;
    switch (tech.status) {
      case 'Active':
        statusColor = const Color(0xFF0D9488);
        statusIcon = Icons.radio_button_on;
        statusLabel = 'Active';
        break;
      case 'Busy':
        statusColor = Colors.orangeAccent;
        statusIcon = Icons.hourglass_top_rounded;
        statusLabel = 'Busy';
        break;
      default:
        statusColor = const Color(0xFF475569);
        statusIcon = Icons.circle_outlined;
        statusLabel = 'Offline';
    }

    final assignedTickets =
        MockDatabase.instance.getTicketsForTechnician(tech.name);
    final activeTickets =
        assignedTickets.where((t) => t.status != 'Delivered').toList();

    return GlassCard(
      padding: const EdgeInsets.all(16),
      opacity: 0.07,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 24,
                    backgroundImage: NetworkImage(tech.imageUrl),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 11,
                      height: 11,
                      decoration: BoxDecoration(
                        color: statusColor,
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: const Color(0xFF0F172A), width: 2),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tech.name,
                        style: GoogleFonts.outfit(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold)),
                    Text(tech.role,
                        style: GoogleFonts.inter(
                            color: const Color(0xFF64748B), fontSize: 12)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => _showStatusMenu(tech),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: statusColor.withOpacity(0.35)),
                  ),
                  child: Row(
                    children: [
                      Icon(statusIcon, size: 12, color: statusColor),
                      const SizedBox(width: 5),
                      Text(statusLabel,
                          style: GoogleFonts.inter(
                              color: statusColor,
                              fontSize: 11,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(width: 4),
                      Icon(Icons.keyboard_arrow_down_rounded,
                          size: 14, color: statusColor),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // Stats row
          Row(
            children: [
              _buildStatChip('${tech.activeJobs}', 'Active Jobs',
                  Colors.cyanAccent),
              const SizedBox(width: 8),
              _buildStatChip('${tech.totalRepairs}', 'Total Repairs',
                  const Color(0xFFA78BFA)),
              const SizedBox(width: 8),
              _buildStatChip(
                  '${(tech.successRate * 100).toInt()}%',
                  'Success',
                  Colors.amberAccent),
            ],
          ),
          if (activeTickets.isNotEmpty) ...[
            const SizedBox(height: 14),
            const Divider(color: Colors.white10, height: 1),
            const SizedBox(height: 12),
            Text('Currently Working On',
                style: GoogleFonts.inter(
                    color: const Color(0xFF64748B),
                    fontSize: 11,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            ...activeTickets.take(2).map((t) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    children: [
                      Container(
                        width: 3,
                        height: 28,
                        decoration: BoxDecoration(
                          color: const Color(0xFF8B5CF6),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${t.brand} ${t.model}',
                              style: GoogleFonts.outfit(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600),
                            ),
                            Text(
                              '${t.id}  •  ${t.subStatus}',
                              style: GoogleFonts.inter(
                                  color: const Color(0xFF64748B),
                                  fontSize: 10),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: const Color(0xFF8B5CF6).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '${(t.progress * 100).toInt()}%',
                          style: GoogleFonts.inter(
                              color: const Color(0xFFA78BFA),
                              fontSize: 10,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                )),
          ],
        ],
      ),
    )
        .animate(delay: (index * 70).ms)
        .fade(duration: 400.ms)
        .slideY(begin: 0.05);
  }

  Widget _buildStatChip(String value, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.15)),
        ),
        child: Column(
          children: [
            Text(value,
                style: GoogleFonts.outfit(
                    color: color, fontSize: 14, fontWeight: FontWeight.bold)),
            Text(label,
                style: GoogleFonts.inter(
                    color: const Color(0xFF64748B), fontSize: 9)),
          ],
        ),
      ),
    );
  }
}
