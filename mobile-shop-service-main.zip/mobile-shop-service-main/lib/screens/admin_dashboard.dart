import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/glow_button.dart';
import 'login_screen.dart';
import '../data/mock_database.dart';
import '../models/customer.dart';
import '../models/repair_ticket.dart';
import '../models/technician.dart';
import 'technician_management_screen.dart';
import 'assign_technician_screen.dart';
import 'daily_task_list_screen.dart';
import 'repair_notes_screen.dart';
import 'completion_report_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _activeTab = 0;
  String _customerSearchQuery = '';
  final _searchController = TextEditingController();

  String _repairSearchQuery = '';
  final _repairSearchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    MockDatabase.instance.addListener(_onDatabaseChanged);
  }

  void _onDatabaseChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    MockDatabase.instance.removeListener(_onDatabaseChanged);
    _searchController.dispose();
    _repairSearchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          // Background glow
          Positioned(
            top: -50,
            right: -50,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF8B5CF6).withOpacity(0.08),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF8B5CF6).withOpacity(0.08),
                    blurRadius: 100,
                    spreadRadius: 40,
                  )
                ],
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1000),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 16),
                      _buildHeader(),
                      const SizedBox(height: 20),
                      _buildTabs(),
                      const SizedBox(height: 16),
                      Expanded(
                        child: IndexedStack(
                          index: _activeTab,
                          children: [
                            _buildOverviewTab(),
                            _buildTechniciansTab(),
                            _buildRepairsTab(),
                            _buildCustomersTab(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFF8B5CF6), width: 2),
          ),
          child: const CircleAvatar(
            radius: 24,
            backgroundImage: NetworkImage('https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=256'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome, Sarah',
                style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'System Administrator',
                style: GoogleFonts.inter(
                  color: const Color(0xFFA78BFA),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        IconButton(
          icon: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.logout_rounded, color: Colors.redAccent, size: 20),
          ),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const LoginScreen()),
            );
          },
        ),
      ],
    ).animate().fade(duration: 500.ms).slideY(begin: -0.1);
  }

  Widget _buildTabs() {
    final tabs = ['Overview', 'Technicians', 'Repairs', 'Customers'];
    return Container(
      height: 48,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(
        children: List.generate(tabs.length, (index) {
          final isActive = _activeTab == index;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _activeTab = index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                decoration: BoxDecoration(
                  color: isActive ? const Color(0xFF8B5CF6).withOpacity(0.15) : Colors.transparent,
                  borderRadius: BorderRadius.circular(8),
                  border: isActive
                      ? Border.all(color: const Color(0xFF8B5CF6).withOpacity(0.3))
                      : null,
                ),
                child: Center(
                  child: Text(
                    tabs[index],
                    style: GoogleFonts.inter(
                      color: isActive ? Colors.white : const Color(0xFF94A3B8),
                      fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    ).animate().fade(duration: 500.ms, delay: 100.ms);
  }

  Widget _buildOverviewTab() {
    final activeJobs = MockDatabase.instance.tickets.where((t) => t.status != 'Delivered').length;
    final pending = MockDatabase.instance.tickets.where((t) => t.status == 'Pending').length;
    final completedOrDelivered = MockDatabase.instance.tickets.where((t) => t.status == 'Completed' || t.status == 'Delivered').length;
    final revenue = completedOrDelivered * 120 + 4500;
    final activeTechs = MockDatabase.instance.tickets.map((t) => t.techName).where((name) => name != 'Assigning Tech...').toSet().length;

    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isDesktop = screenWidth > 720;

    // Calculate weekly counts dynamically
    final tickets = MockDatabase.instance.tickets;
    final Map<int, int> weekdayCounts = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0};
    for (var ticket in tickets) {
      final day = ticket.serviceDate.weekday;
      if (weekdayCounts.containsKey(day)) {
        weekdayCounts[day] = weekdayCounts[day]! + 1;
      }
    }
    final maxCount = weekdayCounts.values.reduce((a, b) => a > b ? a : b);
    const double baseMaxHeight = 85.0;
    double getHeight(int day) {
      if (maxCount == 0) return 4.0;
      final count = weekdayCounts[day] ?? 0;
      if (count == 0) return 4.0;
      return (count / maxCount) * baseMaxHeight;
    }

    return ListView(
      physics: const BouncingScrollPhysics(),
      children: [
        // Stats grid
        GridView.count(
          crossAxisCount: isDesktop ? 4 : 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: isDesktop ? 1.6 : 1.5,
          children: [
            _buildStatCard('Active Jobs', '$activeJobs', Icons.assignment_turned_in_rounded, const Color(0xFF8B5CF6)),
            _buildStatCard('Pending', '$pending', Icons.pending_actions_rounded, Colors.orangeAccent),
            _buildStatCard('Revenue', '\$${revenue.toString().replaceAllMapped(RegExp(r"(\d{1,3})(?=(\d{3})+(?!\d))"), (Match m) => "${m[1]},")}', Icons.monetization_on_rounded, Colors.greenAccent),
            _buildStatCard('Techs Active', '$activeTechs / 4', Icons.engineering_rounded, Colors.cyanAccent),
          ],
        ),

        const SizedBox(height: 24),

        // Custom chart card
        GlassCard(
          opacity: 0.08,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Weekly Ticket Analytics',
                    style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Target: +12%',
                    style: GoogleFonts.inter(color: Colors.greenAccent, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Simple bar chart representation
              SizedBox(
                height: 140,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _buildBar('Mon', weekdayCounts[1] ?? 0, getHeight(1), const Color(0xFF8B5CF6)),
                    _buildBar('Tue', weekdayCounts[2] ?? 0, getHeight(2), const Color(0xFF8B5CF6)),
                    _buildBar('Wed', weekdayCounts[3] ?? 0, getHeight(3), const Color(0xFF8B5CF6)),
                    _buildBar('Thu', weekdayCounts[4] ?? 0, getHeight(4), const Color(0xFF8B5CF6)),
                    _buildBar('Fri', weekdayCounts[5] ?? 0, getHeight(5), const Color(0xFF8B5CF6)),
                    _buildBar('Sat', weekdayCounts[6] ?? 0, getHeight(6), const Color(0xFF8B5CF6)),
                    _buildBar('Sun', weekdayCounts[7] ?? 0, getHeight(7), const Color(0xFF8B5CF6)),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 24),

        // Recent alerts
        Text(
          'Live Service Feed',
          style: GoogleFonts.outfit(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 3,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final feeds = [
              _FeedItem('John Doe completed Macbook Pro screen repair', '10m ago', Icons.check_circle, Colors.greenAccent),
              _FeedItem('New ticket #1980 created: Dyson Fan issues', '32m ago', Icons.add_circle, Colors.cyanAccent),
              _FeedItem('Lisa Vance requested urgent status update', '1h ago', Icons.warning_amber_rounded, Colors.orangeAccent),
            ];
            return _buildFeedTile(feeds[index]);
          },
        ),
        const SizedBox(height: 20),
      ],
    ).animate().fade(duration: 400.ms);
  }

  Widget _buildStatCard(String title, String val, IconData icon, Color color) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      opacity: 0.08,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(icon, color: color, size: 20),
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(shape: BoxShape.circle, color: color),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    val,
                    style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 1),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    title,
                    style: GoogleFonts.inter(
                      color: const Color(0xFF94A3B8),
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBar(String day, int count, double percentage, Color color) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        if (count > 0)
          Text(
            '$count',
            style: GoogleFonts.inter(
              color: Colors.white70,
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
          )
        else
          const SizedBox(height: 12),
        const SizedBox(height: 4),
        Container(
          width: 16,
          height: percentage,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                color,
                color.withOpacity(0.4),
              ],
            ),
            borderRadius: BorderRadius.circular(4),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.3), blurRadius: 6, offset: const Offset(0, 2)),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          day,
          style: GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 11),
        ),
      ],
    );
  }

  Widget _buildFeedTile(_FeedItem feed) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      opacity: 0.06,
      child: Row(
        children: [
          Icon(feed.icon, color: feed.color, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              feed.text,
              style: GoogleFonts.inter(color: Colors.white, fontSize: 13),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            feed.time,
            style: GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 11),
          ),
        ],
      ),
    );
  }

  Widget _buildTechniciansTab() {
    final technicians = MockDatabase.instance.technicians;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Manage button row
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const TechnicianManagementScreen()),
                ),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF0D9488), Color(0xFF0F766E)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xFF0D9488).withOpacity(0.3),
                          blurRadius: 10,
                          offset: const Offset(0, 4)),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.engineering_rounded,
                          color: Colors.white, size: 18),
                      const SizedBox(width: 8),
                      Text('Open Technician Hub',
                          style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: () => _showTechnicianDialog(),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF0D9488).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: const Color(0xFF0D9488).withOpacity(0.3)),
                ),
                child: const Icon(Icons.person_add_alt_1_rounded,
                    color: Colors.white, size: 20),
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const CompletionReportScreen()),
              ),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.amberAccent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: Colors.amberAccent.withOpacity(0.25)),
                ),
                child: const Icon(Icons.bar_chart_rounded,
                    color: Colors.amberAccent, size: 20),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        Expanded(
          child: ListView.separated(
            physics: const BouncingScrollPhysics(),
            itemCount: technicians.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, index) {
              final tech = technicians[index];
              Color statusColor;
              switch (tech.status) {
                case 'Active':
                  statusColor = const Color(0xFF0D9488);
                  break;
                case 'Busy':
                  statusColor = Colors.orangeAccent;
                  break;
                default:
                  statusColor = Colors.grey;
              }
              return GestureDetector(
                onTap: () => _showTechQuickActions(tech),
                child: GlassCard(
                  padding: const EdgeInsets.all(16),
                  opacity: 0.08,
                  child: Row(
                    children: [
                      Stack(
                        children: [
                          CircleAvatar(
                            radius: 22,
                            backgroundImage: NetworkImage(tech.imageUrl),
                          ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              width: 10,
                              height: 10,
                              decoration: BoxDecoration(
                                color: statusColor,
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: const Color(0xFF0F172A), width: 1.5),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(tech.name,
                                style: GoogleFonts.outfit(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold)),
                            Text(tech.role,
                                style: GoogleFonts.inter(
                                    color: const Color(0xFF94A3B8),
                                    fontSize: 12)),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: statusColor),
                              ),
                              const SizedBox(width: 6),
                              Text(tech.status,
                                  style: GoogleFonts.inter(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Rate: ${(tech.successRate * 100).toInt()}%',
                            style: GoogleFonts.inter(
                                color: const Color(0xFFA78BFA),
                                fontSize: 11,
                                fontWeight: FontWeight.w600),
                          ),
                          Text(
                            '${tech.activeJobs} active job${tech.activeJobs != 1 ? 's' : ''}',
                            style: GoogleFonts.inter(
                                color: const Color(0xFF64748B),
                                fontSize: 10),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    ).animate().fade(duration: 400.ms);
  }

  void _showTechQuickActions(Technician tech) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                    radius: 20,
                    backgroundImage: NetworkImage(tech.imageUrl)),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tech.name,
                        style: GoogleFonts.outfit(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold)),
                    Text(tech.role,
                        style: GoogleFonts.inter(
                            color: const Color(0xFF94A3B8), fontSize: 12)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(color: Colors.white10),
            _sheetAction(Icons.person_add_alt_1_rounded, 'Assign to Ticket',
                const Color(0xFF8B5CF6), () {
              Navigator.pop(context);
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) =>
                          AssignTechnicianScreen(preSelectedTech: tech)));
            }),
            _sheetAction(Icons.checklist_rounded, 'Daily Task List',
                Colors.blueAccent, () {
              Navigator.pop(context);
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) =>
                          DailyTaskListScreen(technician: tech)));
            }),
            _sheetAction(Icons.note_add_rounded, 'Repair Notes',
                const Color(0xFF0D9488), () {
              Navigator.pop(context);
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => RepairNotesScreen(technician: tech)));
            }),
            _sheetAction(Icons.edit_rounded, 'Edit Details',
                Colors.amberAccent, () {
              Navigator.pop(context);
              _showTechnicianDialog(technician: tech);
            }),
            _sheetAction(Icons.delete_forever_rounded, 'Delete Technician',
                Colors.redAccent, () {
              Navigator.pop(context);
              _confirmDeleteTechnician(tech);
            }),
          ],
        ),
      ),
    );
  }

  Widget _sheetAction(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
      title: Text(label,
          style: GoogleFonts.inter(
              color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
      trailing: const Icon(Icons.arrow_forward_ios_rounded,
          color: Colors.white24, size: 14),
      onTap: onTap,
    );
  }

  Widget _buildRepairsTab() {
    final tickets = MockDatabase.instance.tickets;
    final filteredTickets = tickets.where((ticket) {
      final query = _repairSearchQuery.toLowerCase();
      final brand = ticket.brand.toLowerCase();
      final model = ticket.model.toLowerCase();
      final customer = ticket.customerName.toLowerCase();
      final id = ticket.id.toLowerCase();
      final imei = ticket.imei.toLowerCase();
      return brand.contains(query) ||
          model.contains(query) ||
          customer.contains(query) ||
          id.contains(query) ||
          imei.contains(query);
    }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Search & Add Row
        Row(
          children: [
            Expanded(
              child: GlassCard(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                opacity: 0.06,
                child: Row(
                  children: [
                    const Icon(Icons.search_rounded, color: Color(0xFF94A3B8), size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _repairSearchController,
                        onChanged: (val) {
                          setState(() {
                            _repairSearchQuery = val;
                          });
                        },
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        decoration: const InputDecoration(
                          hintText: 'Search brand, model, customer or IMEI...',
                          hintStyle: TextStyle(color: Colors.white30, fontSize: 13),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                    if (_repairSearchQuery.isNotEmpty)
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white30, size: 16),
                        onPressed: () {
                          setState(() {
                            _repairSearchController.clear();
                            _repairSearchQuery = '';
                          });
                        },
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            GestureDetector(
              onTap: () => _showAddTicketDialog(),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF8B5CF6).withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFF8B5CF6).withOpacity(0.3)),
                ),
                child: const Icon(Icons.add_task_rounded, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // List of tickets
        Expanded(
          child: filteredTickets.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.build_circle_outlined, color: Colors.white24, size: 48),
                      const SizedBox(height: 12),
                      Text(
                        'No Repair Tickets Found',
                        style: GoogleFonts.outfit(color: Colors.white.withOpacity(0.55), fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Try searching for another device or log a new ticket.',
                        style: GoogleFonts.inter(color: Colors.white38, fontSize: 12),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  physics: const BouncingScrollPhysics(),
                  itemCount: filteredTickets.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final ticket = filteredTickets[index];
                    Color statusColor = Colors.grey;
                    switch (ticket.status) {
                      case 'In Progress':
                        statusColor = const Color(0xFF8B5CF6);
                        break;
                      case 'Pending':
                        statusColor = Colors.cyanAccent;
                        break;
                      case 'Completed':
                        statusColor = Colors.greenAccent;
                        break;
                      case 'Delivered':
                        statusColor = Colors.blueAccent;
                        break;
                    }

                    return GlassCard(
                      padding: const EdgeInsets.all(16),
                      opacity: 0.08,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                ticket.id,
                                style: GoogleFonts.outfit(color: const Color(0xFFA78BFA), fontSize: 12, fontWeight: FontWeight.bold),
                              ),
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: statusColor.withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: statusColor.withOpacity(0.3)),
                                    ),
                                    child: Text(
                                      ticket.status,
                                      style: GoogleFonts.inter(color: statusColor, fontSize: 11, fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  GestureDetector(
                                    onTap: () => _confirmDeleteTicket(ticket),
                                    child: Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: BoxDecoration(
                                        color: Colors.redAccent.withOpacity(0.06),
                                        shape: BoxShape.circle,
                                      ),
                                      child: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 14),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            '${ticket.brand} ${ticket.model}',
                            style: GoogleFonts.outfit(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            ticket.issue,
                            style: GoogleFonts.inter(color: const Color(0xFF94A3B8), fontSize: 13),
                          ),
                          const SizedBox(height: 10),
                          const Divider(color: Colors.white10),
                          const SizedBox(height: 6),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Customer: ${ticket.customerName}',
                                style: GoogleFonts.inter(color: Colors.white38, fontSize: 11),
                              ),
                              Text(
                                'Tech: ${ticket.techName}',
                                style: GoogleFonts.inter(color: const Color(0xFFA78BFA), fontSize: 11, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'IMEI: ${ticket.imei}',
                                style: GoogleFonts.inter(color: Colors.white38, fontSize: 11),
                              ),
                              Text(
                                'Warranty: ${ticket.warranty}',
                                style: GoogleFonts.inter(color: Colors.white38, fontSize: 11),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    ).animate().fade(duration: 400.ms);
  }

  void _confirmDeleteTicket(RepairTicket ticket) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          opacity: 0.16,
          color: Colors.black,
          borderRadius: BorderRadius.circular(24.0),
          border: Border.all(
            color: Colors.redAccent.withOpacity(0.2),
            width: 1.5,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.redAccent.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'Delete Ticket',
                    style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                'Are you sure you want to delete ticket ${ticket.id} (${ticket.brand} ${ticket.model})? This action cannot be undone.',
                style: GoogleFonts.inter(
                  color: const Color(0xFF94A3B8),
                  fontSize: 14,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white70,
                      ),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GlowButton(
                      onPressed: () {
                        MockDatabase.instance.deleteTicket(ticket.id);
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                           SnackBar(
                            backgroundColor: Colors.redAccent,
                            content: Text('Ticket ${ticket.id} has been deleted.'),
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        );
                      },
                      text: 'Delete',
                      gradientColors: const [Colors.redAccent, Colors.red],
                      shadowColor: Colors.redAccent,
                      height: 44,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddTicketDialog() {
    final formKey = GlobalKey<FormState>();
    Customer? selectedCustomer;
    String? selectedBrand;
    final modelController = TextEditingController();
    final imeiController = TextEditingController();
    final issueController = TextEditingController();
    String selectedWarranty = 'None';
    String selectedTech = 'Assigning Tech...';

    DateTime serviceDate = DateTime.now();
    DateTime deliveryDate = DateTime.now().add(const Duration(days: 3));

    final brands = ['Apple', 'Samsung', 'Sony', 'Dyson', 'Google', 'Xiaomi', 'Other'];
    final techNames = ['John Miller', 'Alex Carter', 'Michael Vance', 'Samantha Reed', 'Assigning Tech...'];
    final warranties = ['None', '3 Months', '6 Months', '12 Months'];

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: GlassCard(
                opacity: 0.16,
                color: Colors.black,
                borderRadius: BorderRadius.circular(24.0),
                border: Border.all(
                  color: const Color(0xFF8B5CF6).withOpacity(0.2),
                  width: 1.5,
                ),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(4.0),
                  child: Form(
                    key: formKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Add Mobile Ticket',
                              style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close, color: Colors.white, size: 20),
                              onPressed: () => Navigator.pop(context),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        // Customer dropdown
                        DropdownButtonFormField<Customer>(
                          value: selectedCustomer,
                          hint: Text('Select Customer', style: GoogleFonts.inter(color: Colors.white30, fontSize: 13)),
                          dropdownColor: const Color(0xFF0F172A),
                          style: GoogleFonts.inter(color: Colors.white, fontSize: 14),
                          decoration: InputDecoration(
                            labelText: 'Customer *',
                            labelStyle: GoogleFonts.inter(color: const Color(0xFF8B5CF6)),
                            prefixIcon: const Icon(Icons.person_outline_rounded, color: Color(0xFF8B5CF6)),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white10),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(color: Color(0xFF8B5CF6)),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: MockDatabase.instance.customers.map((cust) {
                            return DropdownMenuItem<Customer>(
                              value: cust,
                              child: Text('${cust.name} (${cust.phone})'),
                            );
                          }).toList(),
                          onChanged: (cust) {
                            setDialogState(() {
                              selectedCustomer = cust;
                            });
                          },
                          validator: (v) => v == null ? 'Customer is required' : null,
                        ),
                        const SizedBox(height: 16),

                        // Brand dropdown
                        DropdownButtonFormField<String>(
                          value: selectedBrand,
                          hint: Text('Select Brand', style: GoogleFonts.inter(color: Colors.white30, fontSize: 13)),
                          dropdownColor: const Color(0xFF0F172A),
                          style: GoogleFonts.inter(color: Colors.white, fontSize: 14),
                          decoration: InputDecoration(
                            labelText: 'Brand *',
                            labelStyle: GoogleFonts.inter(color: const Color(0xFF8B5CF6)),
                            prefixIcon: const Icon(Icons.branding_watermark_outlined, color: Color(0xFF8B5CF6)),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white10),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(color: Color(0xFF8B5CF6)),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: brands.map((b) {
                            return DropdownMenuItem<String>(
                              value: b,
                              child: Text(b),
                            );
                          }).toList(),
                          onChanged: (val) {
                            setDialogState(() {
                              selectedBrand = val;
                            });
                          },
                          validator: (v) => v == null ? 'Brand is required' : null,
                        ),
                        const SizedBox(height: 16),

                        // Model
                        CustomTextField(
                          controller: modelController,
                          labelText: 'Model *',
                          hintText: 'e.g. iPhone 15 Pro Max',
                          prefixIcon: Icons.phone_android_rounded,
                          focusColor: const Color(0xFF8B5CF6),
                          validator: (v) => v == null || v.trim().isEmpty ? 'Model is required' : null,
                        ),
                        const SizedBox(height: 16),

                        // IMEI
                        CustomTextField(
                          controller: imeiController,
                          labelText: 'IMEI (15 Digits) *',
                          hintText: 'e.g. 358901234567890',
                          prefixIcon: Icons.fingerprint_rounded,
                          keyboardType: TextInputType.number,
                          focusColor: const Color(0xFF8B5CF6),
                          validator: (v) {
                            if (v == null || v.trim().isEmpty) return 'IMEI is required';
                            if (!RegExp(r'^\d{15}$').hasMatch(v.trim())) {
                              return 'IMEI must be exactly 15 digits';
                            }
                            return null;
                          },
                        ),
                        const SizedBox(height: 16),

                        // Issue
                        CustomTextField(
                          controller: issueController,
                          labelText: 'Problem Description *',
                          hintText: 'e.g. Cracked screen, water damage...',
                          prefixIcon: Icons.report_problem_outlined,
                          focusColor: const Color(0xFF8B5CF6),
                          validator: (v) => v == null || v.trim().isEmpty ? 'Problem description is required' : null,
                        ),
                        const SizedBox(height: 16),

                        // Service Date & Delivery Date Row
                        Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () async {
                                  final picked = await showDatePicker(
                                    context: context,
                                    initialDate: serviceDate,
                                    firstDate: DateTime.now().subtract(const Duration(days: 30)),
                                    lastDate: DateTime.now().add(const Duration(days: 30)),
                                    builder: (context, child) {
                                      return Theme(
                                        data: Theme.of(context).copyWith(
                                          colorScheme: const ColorScheme.dark(
                                            primary: Color(0xFF8B5CF6),
                                            surface: Color(0xFF0F172A),
                                          ),
                                        ),
                                        child: child!,
                                      );
                                    },
                                  );
                                  if (picked != null) {
                                    setDialogState(() {
                                      serviceDate = picked;
                                    });
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.white10),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.calendar_today_rounded, color: Color(0xFF8B5CF6), size: 16),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          'Service: ${serviceDate.toString().split(' ')[0]}',
                                          style: GoogleFonts.inter(color: Colors.white, fontSize: 12),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: GestureDetector(
                                onTap: () async {
                                  final picked = await showDatePicker(
                                    context: context,
                                    initialDate: deliveryDate,
                                    firstDate: DateTime.now().subtract(const Duration(days: 30)),
                                    lastDate: DateTime.now().add(const Duration(days: 60)),
                                    builder: (context, child) {
                                      return Theme(
                                        data: Theme.of(context).copyWith(
                                          colorScheme: const ColorScheme.dark(
                                            primary: Color(0xFF8B5CF6),
                                            surface: Color(0xFF0F172A),
                                          ),
                                        ),
                                        child: child!,
                                      );
                                    },
                                  );
                                  if (picked != null) {
                                    setDialogState(() {
                                      deliveryDate = picked;
                                    });
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.white10),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.delivery_dining_rounded, color: Color(0xFF8B5CF6), size: 16),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          'Delivery: ${deliveryDate.toString().split(' ')[0]}',
                                          style: GoogleFonts.inter(color: Colors.white, fontSize: 12),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),

                        // Warranty Dropdown
                        DropdownButtonFormField<String>(
                          value: selectedWarranty,
                          dropdownColor: const Color(0xFF0F172A),
                          style: GoogleFonts.inter(color: Colors.white, fontSize: 14),
                          decoration: InputDecoration(
                            labelText: 'Warranty Track *',
                            labelStyle: GoogleFonts.inter(color: const Color(0xFF8B5CF6)),
                            prefixIcon: const Icon(Icons.verified_user_outlined, color: Color(0xFF8B5CF6)),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white10),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(color: Color(0xFF8B5CF6)),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: warranties.map((w) {
                            return DropdownMenuItem<String>(
                              value: w,
                              child: Text(w),
                            );
                          }).toList(),
                          onChanged: (val) {
                            setDialogState(() {
                              selectedWarranty = val ?? 'None';
                            });
                          },
                        ),
                        const SizedBox(height: 16),

                        // Assign Tech Dropdown
                        DropdownButtonFormField<String>(
                          value: selectedTech,
                          dropdownColor: const Color(0xFF0F172A),
                          style: GoogleFonts.inter(color: Colors.white, fontSize: 14),
                          decoration: InputDecoration(
                            labelText: 'Assign Technician',
                            labelStyle: GoogleFonts.inter(color: const Color(0xFF8B5CF6)),
                            prefixIcon: const Icon(Icons.engineering_outlined, color: Color(0xFF8B5CF6)),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white10),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(color: Color(0xFF8B5CF6)),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: techNames.map((t) {
                            return DropdownMenuItem<String>(
                              value: t,
                              child: Text(t),
                            );
                          }).toList(),
                          onChanged: (val) {
                            setDialogState(() {
                              selectedTech = val ?? 'Assigning Tech...';
                            });
                          },
                        ),
                        const SizedBox(height: 24),

                        // Submit
                        GlowButton(
                          onPressed: () {
                            if (formKey.currentState!.validate() && selectedCustomer != null && selectedBrand != null) {
                              final newId = 'T-${MockDatabase.instance.tickets.length + 1097}';
                              final ticket = RepairTicket(
                                id: newId,
                                customerId: selectedCustomer!.id,
                                customerName: selectedCustomer!.name,
                                customerPhone: selectedCustomer!.phone,
                                brand: selectedBrand!,
                                model: modelController.text.trim(),
                                imei: imeiController.text.trim(),
                                issue: issueController.text.trim(),
                                status: 'Pending',
                                subStatus: 'Received',
                                progress: 0.2,
                                serviceDate: serviceDate,
                                deliveryDate: deliveryDate,
                                warranty: selectedWarranty,
                                techName: selectedTech,
                              );
                              MockDatabase.instance.addTicket(ticket);
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  backgroundColor: const Color(0xFF8B5CF6),
                                  content: Text('Ticket $newId logged successfully!'),
                                  behavior: SnackBarBehavior.floating,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                              );
                            }
                          },
                          text: 'Log Ticket',
                          icon: Icons.assignment_turned_in_rounded,
                          gradientColors: const [Color(0xFF8B5CF6), Color(0xFF7C3AED)],
                          shadowColor: const Color(0xFF8B5CF6),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showTechnicianDialog({Technician? technician}) {
    final isEdit = technician != null;
    final nameController = TextEditingController(text: isEdit ? technician.name : '');
    final roleController = TextEditingController(text: isEdit ? technician.role : '');
    final emailController = TextEditingController(text: isEdit ? technician.email : '');
    final phoneController = TextEditingController(text: isEdit ? technician.phone : '');
    final specController = TextEditingController(
        text: isEdit ? technician.specializations.join(', ') : '');
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: SingleChildScrollView(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: GlassCard(
              opacity: 0.16,
              color: Colors.black,
              borderRadius: BorderRadius.circular(24.0),
              border: Border.all(
                color: const Color(0xFF0D9488).withOpacity(0.25),
                width: 1.5,
              ),
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          isEdit ? 'Edit Technician' : 'Add Technician',
                          style: GoogleFonts.outfit(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.white, size: 20),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    CustomTextField(
                      controller: nameController,
                      labelText: 'Full Name',
                      hintText: 'e.g. John Doe',
                      prefixIcon: Icons.person_rounded,
                      focusColor: const Color(0xFF0D9488),
                      validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Name is required' : null,
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: roleController,
                      labelText: 'Role / Title',
                      hintText: 'e.g. Senior Hardware Specialist',
                      prefixIcon: Icons.badge_rounded,
                      focusColor: const Color(0xFF0D9488),
                      validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Role is required' : null,
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: emailController,
                      labelText: 'Email Address',
                      hintText: 'e.g. john.doe@mobitracker.com',
                      prefixIcon: Icons.alternate_email_rounded,
                      keyboardType: TextInputType.emailAddress,
                      focusColor: const Color(0xFF0D9488),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Email is required';
                        if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(v)) {
                          return 'Enter a valid email address';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: phoneController,
                      labelText: 'Mobile Number',
                      hintText: 'e.g. +1 (555) 012-3456',
                      prefixIcon: Icons.phone_android_rounded,
                      keyboardType: TextInputType.phone,
                      focusColor: const Color(0xFF0D9488),
                      validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Phone is required' : null,
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: specController,
                      labelText: 'Specializations (comma separated)',
                      hintText: 'e.g. iPhone, MacBook, Soldering',
                      prefixIcon: Icons.handyman_rounded,
                      focusColor: const Color(0xFF0D9488),
                    ),
                    const SizedBox(height: 24),
                    GlowButton(
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          final specs = specController.text
                              .split(',')
                              .map((s) => s.trim())
                              .where((s) => s.isNotEmpty)
                              .toList();
                          if (isEdit) {
                            final updated = technician.copyWith(
                              name: nameController.text.trim(),
                              role: roleController.text.trim(),
                              email: emailController.text.trim(),
                              phone: phoneController.text.trim(),
                              specializations: specs,
                            );
                            MockDatabase.instance.editTechnician(updated);
                          } else {
                            final newId = 'T-${DateTime.now().millisecondsSinceEpoch}';
                            final newTech = Technician(
                              id: newId,
                              name: nameController.text.trim(),
                              role: roleController.text.trim(),
                              email: emailController.text.trim(),
                              phone: phoneController.text.trim(),
                              imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=256',
                              status: 'Offline',
                              successRate: 0.95,
                              totalRepairs: 0,
                              activeJobs: 0,
                              joinDate: 'May 2026',
                              specializations: specs,
                            );
                            MockDatabase.instance.addTechnician(newTech);
                          }
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              backgroundColor: const Color(0xFF0D9488),
                              content: Text(isEdit
                                  ? 'Technician details updated successfully!'
                                  : 'New technician added successfully!'),
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          );
                        }
                      },
                      text: isEdit ? 'Save Changes' : 'Add Technician',
                      icon: isEdit ? Icons.check_circle_rounded : Icons.person_add_alt_1_rounded,
                      gradientColors: const [Color(0xFF0D9488), Color(0xFF0F766E)],
                      shadowColor: const Color(0xFF0D9488),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _confirmDeleteTechnician(Technician technician) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          opacity: 0.16,
          color: Colors.black,
          borderRadius: BorderRadius.circular(24.0),
          border: Border.all(
            color: Colors.redAccent.withOpacity(0.2),
            width: 1.5,
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.redAccent.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 24),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Delete Technician',
                      style: GoogleFonts.outfit(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Are you sure you want to delete technician ${technician.name}? This action cannot be undone.',
                  style: GoogleFonts.inter(
                    color: const Color(0xFF94A3B8),
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.pop(context),
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white70,
                        ),
                        child: const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GlowButton(
                        onPressed: () {
                          MockDatabase.instance.deleteTechnician(technician.id);
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              backgroundColor: Colors.redAccent,
                              content: Text('Technician ${technician.name} deleted successfully!'),
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          );
                        },
                        text: 'Delete',
                        icon: Icons.delete_forever_rounded,
                        gradientColors: const [Colors.redAccent, Color(0xFFDC2626)],
                        shadowColor: Colors.redAccent,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showCustomerDialog({Customer? customer}) {
    final isEdit = customer != null;
    final nameController = TextEditingController(text: isEdit ? customer.name : '');
    final emailController = TextEditingController(text: isEdit ? customer.email : '');
    final phoneController = TextEditingController(text: isEdit ? customer.phone : '');
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          opacity: 0.16,
          color: Colors.black,
          borderRadius: BorderRadius.circular(24.0),
          border: Border.all(
            color: const Color(0xFF8B5CF6).withOpacity(0.2),
            width: 1.5,
          ),
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      isEdit ? 'Edit Customer' : 'Add Customer',
                      style: GoogleFonts.outfit(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white, size: 20),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  isEdit
                      ? 'Update details for this customer registry.'
                      : 'Create a new customer profile for service tracking.',
                  style: GoogleFonts.inter(
                    color: const Color(0xFF94A3B8),
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 20),
                CustomTextField(
                  controller: nameController,
                  labelText: 'Full Name',
                  hintText: 'e.g. John Doe',
                  prefixIcon: Icons.person_outline_rounded,
                  focusColor: const Color(0xFF8B5CF6),
                  validator: (v) => v == null || v.trim().isEmpty ? 'Name is required' : null,
                ),
                const SizedBox(height: 16),
                CustomTextField(
                  controller: emailController,
                  labelText: 'Email Address',
                  hintText: 'e.g. john.doe@example.com',
                  prefixIcon: Icons.alternate_email_rounded,
                  keyboardType: TextInputType.emailAddress,
                  focusColor: const Color(0xFF8B5CF6),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'Email is required';
                    if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(v)) {
                      return 'Enter a valid email address';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                CustomTextField(
                  controller: phoneController,
                  labelText: 'Mobile Number',
                  hintText: 'e.g. +1 (555) 019-2834',
                  prefixIcon: Icons.phone_android_rounded,
                  keyboardType: TextInputType.phone,
                  focusColor: const Color(0xFF8B5CF6),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'Mobile number is required';
                    if (v.trim().replaceAll(RegExp(r'\D'), '').length < 7) {
                      return 'Enter a valid phone number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                GlowButton(
                  onPressed: () {
                    if (formKey.currentState!.validate()) {
                      if (isEdit) {
                        final updated = customer.copyWith(
                          name: nameController.text.trim(),
                          email: emailController.text.trim(),
                          phone: phoneController.text.trim(),
                        );
                        MockDatabase.instance.editCustomer(updated);
                      } else {
                        final newId = 'C-${MockDatabase.instance.customers.length + 101}';
                        final newCust = Customer(
                          id: newId,
                          name: nameController.text.trim(),
                          email: emailController.text.trim(),
                          phone: phoneController.text.trim(),
                        );
                        MockDatabase.instance.addCustomer(newCust);
                      }
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          backgroundColor: const Color(0xFF8B5CF6),
                          content: Text(isEdit
                              ? 'Customer details updated successfully!'
                              : 'New customer added successfully!'),
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      );
                    }
                  },
                  text: isEdit ? 'Save Changes' : 'Add Customer',
                  icon: isEdit ? Icons.check_circle_rounded : Icons.person_add_rounded,
                  gradientColors: const [Color(0xFF8B5CF6), Color(0xFF7C3AED)],
                  shadowColor: const Color(0xFF8B5CF6),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _confirmDeleteCustomer(Customer customer) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          opacity: 0.16,
          color: Colors.black,
          borderRadius: BorderRadius.circular(24.0),
          border: Border.all(
            color: Colors.redAccent.withOpacity(0.2),
            width: 1.5,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.redAccent.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'Delete Customer',
                    style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                'Are you sure you want to delete customer ${customer.name}? This action cannot be undone and will delete all associated repair logs.',
                style: GoogleFonts.inter(
                  color: const Color(0xFF94A3B8),
                  fontSize: 14,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white70,
                      ),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GlowButton(
                      onPressed: () {
                        MockDatabase.instance.deleteCustomer(customer.id);
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            backgroundColor: Colors.redAccent,
                            content: Text('${customer.name} has been deleted.'),
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        );
                      },
                      text: 'Delete',
                      gradientColors: const [Colors.redAccent, Colors.red],
                      shadowColor: Colors.redAccent,
                      height: 44,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showServiceHistoryBottomSheet(Customer customer) {
    final history = MockDatabase.instance.getTicketsForCustomer(customer.id);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0F172A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.6,
          maxChildSize: 0.9,
          minChildSize: 0.4,
          expand: false,
          builder: (context, scrollController) {
            return Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Drag indicator
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Title / Info Header
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFF8B5CF6).withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.history_rounded, color: Color(0xFF8B5CF6), size: 24),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Service History',
                              style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              customer.name,
                              style: GoogleFonts.inter(
                                color: const Color(0xFF94A3B8),
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white, size: 20),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Divider(color: Colors.white10),
                  const SizedBox(height: 12),

                  // History list
                  Expanded(
                    child: history.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.assignment_late_outlined, color: Colors.white24, size: 48),
                                const SizedBox(height: 12),
                                Text(
                                  'No Service History Found',
                                  style: GoogleFonts.outfit(color: Colors.white.withOpacity(0.55), fontSize: 16, fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'This customer does not have any active or past repairs.',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.inter(color: Colors.white38, fontSize: 12),
                                ),
                              ],
                            ),
                          )
                        : ListView.separated(
                            controller: scrollController,
                            physics: const BouncingScrollPhysics(),
                            itemCount: history.length,
                            separatorBuilder: (context, index) => const SizedBox(height: 12),
                            itemBuilder: (context, index) {
                              final log = history[index];
                              Color statusColor = Colors.grey;
                              switch (log.status) {
                                case 'In Progress':
                                  statusColor = const Color(0xFF8B5CF6);
                                  break;
                                case 'Pending':
                                  statusColor = Colors.cyanAccent;
                                  break;
                                case 'Completed':
                                  statusColor = Colors.greenAccent;
                                  break;
                                case 'Delivered':
                                  statusColor = Colors.blueAccent;
                                  break;
                              }

                              return GlassCard(
                                padding: const EdgeInsets.all(16),
                                opacity: 0.08,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          log.id,
                                          style: GoogleFonts.outfit(
                                            color: const Color(0xFFA78BFA),
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: statusColor.withOpacity(0.12),
                                            borderRadius: BorderRadius.circular(12),
                                            border: Border.all(color: statusColor.withOpacity(0.3)),
                                          ),
                                          child: Text(
                                            log.status,
                                            style: GoogleFonts.inter(
                                              color: statusColor,
                                              fontSize: 10,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      '${log.brand} ${log.model}',
                                      style: GoogleFonts.outfit(
                                        color: Colors.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      log.issue,
                                      style: GoogleFonts.inter(
                                        color: const Color(0xFF94A3B8),
                                        fontSize: 12,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      'Logged on: ${log.serviceDate.toString().split(' ')[0]}',
                                      style: GoogleFonts.inter(
                                        color: Colors.white30,
                                        fontSize: 10,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildCustomersTab() {
    final customers = MockDatabase.instance.customers;
    final filteredCustomers = customers.where((customer) {
      final name = customer.name.toLowerCase();
      final email = customer.email.toLowerCase();
      final phone = customer.phone.toLowerCase();
      final query = _customerSearchQuery.toLowerCase();
      return name.contains(query) || email.contains(query) || phone.contains(query);
    }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Search & Add Row
        Row(
          children: [
            Expanded(
              child: GlassCard(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                opacity: 0.06,
                child: Row(
                  children: [
                    const Icon(Icons.search_rounded, color: Color(0xFF94A3B8), size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        onChanged: (val) {
                          setState(() {
                            _customerSearchQuery = val;
                          });
                        },
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        decoration: const InputDecoration(
                          hintText: 'Search name, phone, or email...',
                          hintStyle: TextStyle(color: Colors.white30, fontSize: 13),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                    if (_customerSearchQuery.isNotEmpty)
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white30, size: 16),
                        onPressed: () {
                          setState(() {
                            _searchController.clear();
                            _customerSearchQuery = '';
                          });
                        },
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            GestureDetector(
              onTap: () => _showCustomerDialog(),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF8B5CF6).withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFF8B5CF6).withOpacity(0.3)),
                ),
                child: const Icon(Icons.person_add_alt_1_rounded, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // List of Customers
        Expanded(
          child: filteredCustomers.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.people_outline_rounded, color: Colors.white24, size: 48),
                      const SizedBox(height: 12),
                      Text(
                        'No Customers Found',
                        style: GoogleFonts.outfit(color: Colors.white.withOpacity(0.55), fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Try searching for another name or phone number.',
                        style: GoogleFonts.inter(color: Colors.white38, fontSize: 12),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  physics: const BouncingScrollPhysics(),
                  itemCount: filteredCustomers.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final customer = filteredCustomers[index];
                    final String initials = customer.name
                        .split(' ')
                        .map((s) => s.isNotEmpty ? s[0] : '')
                        .take(2)
                        .join()
                        .toUpperCase();

                    final activeJobsCount = MockDatabase.instance.getActiveTicketsForCustomer(customer.id).length;

                    return GestureDetector(
                      onTap: () => _showServiceHistoryBottomSheet(customer),
                      child: GlassCard(
                        padding: const EdgeInsets.all(16),
                        opacity: 0.08,
                        child: Row(
                          children: [
                            // Avatar
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: [
                                    const Color(0xFF8B5CF6),
                                    const Color(0xFF8B5CF6).withOpacity(0.5),
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  initials,
                                  style: GoogleFonts.outfit(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 14),

                            // Customer Info
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    customer.name,
                                    style: GoogleFonts.outfit(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Row(
                                    children: [
                                      const Icon(Icons.phone_iphone_rounded, color: Colors.white38, size: 12),
                                      const SizedBox(width: 4),
                                      Text(
                                        customer.phone,
                                        style: GoogleFonts.inter(
                                          color: const Color(0xFF94A3B8),
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 1),
                                  Row(
                                    children: [
                                      const Icon(Icons.alternate_email_rounded, color: Colors.white38, size: 12),
                                      const SizedBox(width: 4),
                                      Expanded(
                                        child: Text(
                                          customer.email,
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.inter(
                                            color: const Color(0xFF64748B),
                                            fontSize: 11,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            // Right section - Jobs & Actions
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                // Active Jobs Badge
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: activeJobsCount > 0
                                        ? const Color(0xFF8B5CF6).withOpacity(0.15)
                                        : Colors.white.withOpacity(0.04),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: activeJobsCount > 0
                                          ? const Color(0xFF8B5CF6).withOpacity(0.3)
                                          : Colors.transparent,
                                    ),
                                  ),
                                  child: Text(
                                    '$activeJobsCount Active',
                                    style: GoogleFonts.inter(
                                      color: activeJobsCount > 0 ? const Color(0xFFA78BFA) : Colors.white30,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 8),

                                // Actions
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    GestureDetector(
                                      onTap: () => _showCustomerDialog(customer: customer),
                                      child: Container(
                                        padding: const EdgeInsets.all(6),
                                        decoration: BoxDecoration(
                                          color: Colors.white.withOpacity(0.04),
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Icon(Icons.edit_rounded, color: Color(0xFFA78BFA), size: 14),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    GestureDetector(
                                      onTap: () => _confirmDeleteCustomer(customer),
                                      child: Container(
                                        padding: const EdgeInsets.all(6),
                                        decoration: BoxDecoration(
                                          color: Colors.redAccent.withOpacity(0.06),
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 14),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    ).animate().fade(duration: 400.ms);
  }
}

class _FeedItem {
  final String text;
  final String time;
  final IconData icon;
  final Color color;
  _FeedItem(this.text, this.time, this.icon, this.color);
}

class _Tech {
  final String name;
  final String role;
  final String status;
  final String successRate;
  final Color statusColor;
  final String imageUrl;
  _Tech(this.name, this.role, this.status, this.successRate, this.statusColor, this.imageUrl);
}

class _Ticket {
  final String id;
  final String device;
  final String issue;
  final String status;
  final Color color;
  _Ticket(this.id, this.device, this.issue, this.status, this.color);
}
