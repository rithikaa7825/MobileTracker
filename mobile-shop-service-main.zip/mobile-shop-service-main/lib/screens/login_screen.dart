import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/glow_button.dart';
import '../widgets/custom_text_field.dart';
import 'forgot_password_screen.dart';
import 'admin_dashboard.dart';
import 'technician_dashboard.dart';
import 'customer_dashboard.dart';
import '../data/mock_database.dart';
import '../models/customer.dart';
import '../models/technician.dart';

enum UserRole { admin, technician, customer }

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  UserRole _selectedRole = UserRole.customer;
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;

  // Configuration map for dynamic themes based on selected role
  Map<UserRole, _RoleThemeConfig> get _themeConfigs => {
        UserRole.admin: _RoleThemeConfig(
          title: 'Admin Control Center',
          subtitle: 'Access the system settings & reports.',
          focusColor: const Color(0xFF8B5CF6), // Purple
          accentColor: const Color(0xFFA78BFA),
          icon: Icons.admin_panel_settings_rounded,
          gradientColors: [const Color(0xFF2E1065), const Color(0xFF0F172A)], // Indigo/Purple Dark
          btnGradient: [const Color(0xFF8B5CF6), const Color(0xFF6D28D9)],
          glowColor: const Color(0xFF8B5CF6),
          testEmail: 'admin@mobitracker.com',
          testPassword: 'admin@123',
        ),
        UserRole.technician: _RoleThemeConfig(
          title: 'Technician Hub',
          subtitle: 'Manage repairs, tickets & updates.',
          focusColor: const Color(0xFF0D9488), // Teal
          accentColor: const Color(0xFF2DD4BF),
          icon: Icons.engineering_rounded,
          gradientColors: [const Color(0xFF042F2E), const Color(0xFF0F172A)], // Teal Dark
          btnGradient: [const Color(0xFF0D9488), const Color(0xFF0F766E)],
          glowColor: const Color(0xFF0D9488),
          testEmail: 'name@mobitracker.com',
          testPassword: 'name@123',
        ),
        UserRole.customer: _RoleThemeConfig(
          title: 'Customer Portal',
          subtitle: 'Book services & track repair status.',
          focusColor: const Color(0xFFF43F5E), // Rose
          accentColor: const Color(0xFFFDA4AF),
          icon: Icons.person_rounded,
          gradientColors: [const Color(0xFF4C0519), const Color(0xFF0F172A)], // Rose/Crimson Dark
          btnGradient: [const Color(0xFFF43F5E), const Color(0xFFE11D48)],
          glowColor: const Color(0xFFF43F5E),
          testEmail: 'customer.lisa@gmail.com',
          testPassword: 'customerpassword',
        ),
      };

  @override
  void initState() {
    super.initState();
  }

  void _applyTestCredentials() {
    final config = _themeConfigs[_selectedRole]!;
    _emailController.text = config.testEmail;
    _passwordController.text = config.testPassword;
  }

  void _handleLogin() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      // Simulate network request
      await Future.delayed(const Duration(seconds: 2));

      if (mounted) {
        setState(() {
          _isLoading = false;
        });

        final email = _emailController.text.trim();
        final password = _passwordController.text.trim();
        
        // Helper to generate a clean name from email
        String nameFromEmail(String mail) {
          final part = mail.split('@')[0];
          final words = part.split(RegExp(r'[._-]'));
          return words.map((w) => w.isEmpty ? '' : '${w[0].toUpperCase()}${w.substring(1)}').join(' ');
        }

        if (_selectedRole == UserRole.admin) {
          if (email.toLowerCase() != 'admin@mobitracker.com' || password != 'admin@123') {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                backgroundColor: Colors.redAccent,
                content: const Text('Invalid admin credentials! Use admin@mobitracker.com / admin@123'),
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            );
            return;
          }
        } else if (_selectedRole == UserRole.technician) {
          final emailPrefix = email.split('@')[0];
          final expectedTechPassword = '$emailPrefix@123';
          final isPreSeeded = (email.toLowerCase() == 'tech.john@mobitracker.com' && password == 'techpassword') ||
                              (email.toLowerCase() == 'name@mobitracker.com' && password == 'name@123');
          final isPatternMatch = password == expectedTechPassword;

          if (!isPreSeeded && !isPatternMatch) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                backgroundColor: Colors.redAccent,
                content: Text('Invalid password! For technician logging in, password must be "$expectedTechPassword".'),
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            );
            return;
          }

          final exists = MockDatabase.instance.technicians.any(
            (t) => t.email.toLowerCase() == email.toLowerCase()
          );
          if (!exists) {
            final newTech = Technician(
              id: 'T-${DateTime.now().millisecondsSinceEpoch}',
              name: nameFromEmail(email),
              role: 'Hardware Repair Specialist',
              email: email,
              phone: '+1 (555) 012-9933',
              imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=256',
              status: 'Online',
              successRate: 0.96,
              totalRepairs: 0,
              activeJobs: 0,
              joinDate: 'May 2026',
              specializations: ['Device Diagnostics', 'Soldering', 'Screen Replacement'],
            );
            MockDatabase.instance.addTechnician(newTech);
          }
        } else if (_selectedRole == UserRole.customer) {
          if (email.toLowerCase() == 'customer.lisa@gmail.com' && password != 'customerpassword') {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                backgroundColor: Colors.redAccent,
                content: const Text('Invalid customer credentials!'),
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            );
            return;
          }
          final exists = MockDatabase.instance.customers.any(
            (c) => c.email.toLowerCase() == email.toLowerCase()
          );
          if (!exists) {
            final newCust = Customer(
              id: 'C-${DateTime.now().millisecondsSinceEpoch}',
              name: nameFromEmail(email),
              email: email,
              phone: '+1 (555) 019-8800',
            );
            MockDatabase.instance.addCustomer(newCust);
          }
        }

        // Navigate to the respective dashboard based on the selected role
        Widget dashboard;
        switch (_selectedRole) {
          case UserRole.admin:
            dashboard = const AdminDashboard();
            break;
          case UserRole.technician:
            dashboard = TechnicianDashboard(email: email);
            break;
          case UserRole.customer:
            dashboard = CustomerDashboard(email: email);
            break;
        }

        // Show Success Alert
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: _themeConfigs[_selectedRole]!.focusColor,
            content: Row(
              children: [
                const Icon(Icons.check_circle_outline_rounded, color: Colors.white),
                const SizedBox(width: 12),
                Text(
                  'Successfully logged in as ${_selectedRole.name.toUpperCase()}!',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ],
            ),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => dashboard),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final config = _themeConfigs[_selectedRole]!;

    return Scaffold(
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: config.gradientColors,
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Stack(
          children: [
            // Dynamic glowing blob
            Positioned(
              top: -60,
              left: -60,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 600),
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: config.focusColor.withOpacity(0.18),
                  boxShadow: [
                    BoxShadow(
                      color: config.focusColor.withOpacity(0.18),
                      blurRadius: 100,
                      spreadRadius: 50,
                    ),
                  ],
                ),
              ),
            ),

            SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 550),
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                    // Back arrow / Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Text(
                          'MobiTracker',
                          style: GoogleFonts.outfit(
                            color: Colors.white.withOpacity(0.9),
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 48), // Spacer to balance back arrow
                      ],
                    ),

                    const SizedBox(height: 30),

                    // Role Icon with animated keyframes
                    Center(
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: config.focusColor.withOpacity(0.15),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: config.focusColor.withOpacity(0.3),
                            width: 1.5,
                          ),
                        ),
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 400),
                          transitionBuilder: (child, animation) => ScaleTransition(
                            scale: animation,
                            child: FadeTransition(opacity: animation, child: child),
                          ),
                          child: Icon(
                            config.icon,
                            key: ValueKey(_selectedRole),
                            color: config.accentColor,
                            size: 48,
                          ),
                        ),
                      )
                          .animate(target: _selectedRole.index.toDouble())
                          .shake(duration: 400.ms, curve: Curves.easeInOut),
                    ),

                    const SizedBox(height: 24),

                    // Role Header text
                    Column(
                      children: [
                        Text(
                          config.title,
                          textAlign: TextAlign.center,
                          style: GoogleFonts.outfit(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          config.subtitle,
                          textAlign: TextAlign.center,
                          style: GoogleFonts.inter(
                            color: const Color(0xFF94A3B8),
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 32),

                    // Unified Role Switcher Tabs
                    Container(
                      height: 52,
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(16.0),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.08),
                          width: 1.0,
                        ),
                      ),
                      child: Row(
                        children: UserRole.values.map((role) {
                          final isSelected = _selectedRole == role;
                          return Expanded(
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  _selectedRole = role;
                                  _emailController.clear();
                                  _passwordController.clear();
                                });
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeInOut,
                                decoration: BoxDecoration(
                                  color: isSelected ? config.focusColor : Colors.transparent,
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Center(
                                  child: Text(
                                    role.name.substring(0, 1).toUpperCase() + role.name.substring(1),
                                    style: GoogleFonts.inter(
                                      color: isSelected ? Colors.white : const Color(0xFF94A3B8),
                                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Form Card
                    GlassCard(
                      opacity: 0.08,
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // Email
                            CustomTextField(
                              controller: _emailController,
                              labelText: _selectedRole == UserRole.admin ? 'Admin Email / ID' : 'Email Address',
                              hintText: 'Enter your account email',
                              prefixIcon: Icons.alternate_email_rounded,
                              keyboardType: TextInputType.emailAddress,
                              focusColor: config.focusColor,
                              validator: (val) {
                                if (val == null || val.trim().isEmpty) {
                                  return 'Field is required';
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 20),

                            // Password
                            CustomTextField(
                              controller: _passwordController,
                              labelText: 'Password',
                              hintText: 'Enter your password',
                              prefixIcon: Icons.lock_outline_rounded,
                              isPassword: true,
                              textInputAction: TextInputAction.done,
                              focusColor: config.focusColor,
                              onFieldSubmitted: (_) => _handleLogin(),
                              validator: (val) {
                                if (val == null || val.trim().isEmpty) {
                                  return 'Password is required';
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 12),

                            // Forgot Password Link
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => ForgotPasswordScreen(
                                        primaryColor: config.focusColor,
                                        accentColor: config.accentColor,
                                        initialEmail: _emailController.text,
                                        bgGradient: config.gradientColors,
                                      ),
                                    ),
                                  );
                                },
                                style: TextButton.styleFrom(
                                  foregroundColor: config.accentColor,
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                ),
                                child: Text(
                                  'Forgot Password?',
                                  style: GoogleFonts.inter(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 16),

                            // Login Button
                            GlowButton(
                              onPressed: _handleLogin,
                              text: 'Sign In',
                              icon: Icons.login_rounded,
                              gradientColors: config.btnGradient,
                              shadowColor: config.glowColor,
                              isLoading: _isLoading,
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Click to Auto Fill Help Banner
                    InkWell(
                      onTap: _applyTestCredentials,
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: config.focusColor.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: config.focusColor.withOpacity(0.12),
                            width: 1.0,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.lightbulb_outline_rounded, color: config.accentColor, size: 18),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Tap here to reload demo accounts credentials.',
                                style: GoogleFonts.inter(
                                  color: const Color(0xFF94A3B8),
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 32),

                    // Don't have an account (Customer Registration mockup)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Don't have an account?",
                          style: GoogleFonts.inter(
                            color: const Color(0xFF64748B),
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(width: 6),
                        GestureDetector(
                          onTap: () {
                            // Mock Register trigger
                            _showRegisterMockDialog(context, config);
                          },
                          child: Text(
                            'Sign Up',
                            style: GoogleFonts.inter(
                              color: config.accentColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ),
  ),
    );
  }

  void _showRegisterMockDialog(BuildContext context, _RoleThemeConfig config) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          opacity: 0.16,
          color: Colors.black,
          borderRadius: BorderRadius.circular(24.0),
          border: Border.all(
            color: config.focusColor.withOpacity(0.2),
            width: 1.5,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Create Account',
                    style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                'Sign up as a customer to track your devices & book direct repairs.',
                style: GoogleFonts.inter(
                  color: const Color(0xFF94A3B8),
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: TextEditingController(),
                labelText: 'Full Name',
                hintText: 'Enter your name',
                prefixIcon: Icons.person_outline_rounded,
                focusColor: config.focusColor,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                controller: TextEditingController(),
                labelText: 'Email Address',
                hintText: 'Enter your email',
                prefixIcon: Icons.alternate_email_rounded,
                focusColor: config.focusColor,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                controller: TextEditingController(),
                labelText: 'Password',
                hintText: 'Create a password',
                prefixIcon: Icons.lock_outline_rounded,
                isPassword: true,
                focusColor: config.focusColor,
              ),
              const SizedBox(height: 24),
              GlowButton(
                onPressed: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      backgroundColor: config.focusColor,
                      content: const Text('Customer registration simulation successful!'),
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  );
                },
                text: 'Register Account',
                icon: Icons.how_to_reg_rounded,
                gradientColors: config.btnGradient,
                shadowColor: config.glowColor,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Config class to handle theme variations between roles
class _RoleThemeConfig {
  final String title;
  final String subtitle;
  final Color focusColor;
  final Color accentColor;
  final IconData icon;
  final List<Color> gradientColors;
  final List<Color> btnGradient;
  final Color glowColor;
  final String testEmail;
  final String testPassword;

  _RoleThemeConfig({
    required this.title,
    required this.subtitle,
    required this.focusColor,
    required this.accentColor,
    required this.icon,
    required this.gradientColors,
    required this.btnGradient,
    required this.glowColor,
    required this.testEmail,
    required this.testPassword,
  });
}
