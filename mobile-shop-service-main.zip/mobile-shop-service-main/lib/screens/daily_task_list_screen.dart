import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/glow_button.dart';
import '../data/mock_database.dart';
import '../models/technician.dart';

class DailyTaskListScreen extends StatefulWidget {
  final Technician technician;

  const DailyTaskListScreen({super.key, required this.technician});

  @override
  State<DailyTaskListScreen> createState() => _DailyTaskListScreenState();
}

class _DailyTaskListScreenState extends State<DailyTaskListScreen> {
  late String _techId;

  @override
  void initState() {
    super.initState();
    _techId = widget.technician.id;
    MockDatabase.instance.addListener(_onDbChanged);
  }

  void _onDbChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    MockDatabase.instance.removeListener(_onDbChanged);
    super.dispose();
  }

  Technician get _tech =>
      MockDatabase.instance.getTechnicianById(_techId) ?? widget.technician;

  void _showAddTaskDialog() {
    final ticketController = TextEditingController();
    final customerController = TextEditingController();
    final deviceController = TextEditingController();
    final taskController = TextEditingController();
    String priority = 'Medium';
    TimeOfDay scheduledTime = TimeOfDay.now();

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          child: GlassCard(
            opacity: 0.18,
            color: Colors.black,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
                color: Colors.blueAccent.withOpacity(0.2)),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.blueAccent.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.add_task_rounded,
                            color: Colors.blueAccent, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Text('Add New Task',
                          style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _dialogField(ticketController, 'Ticket ID', Icons.tag_rounded),
                  const SizedBox(height: 12),
                  _dialogField(customerController, 'Customer Name',
                      Icons.person_rounded),
                  const SizedBox(height: 12),
                  _dialogField(
                      deviceController, 'Device Name', Icons.smartphone_rounded),
                  const SizedBox(height: 12),
                  _dialogField(taskController, 'Task Description',
                      Icons.description_rounded,
                      maxLines: 3),
                  const SizedBox(height: 16),
                  // Priority selector
                  Text('Priority',
                      style: GoogleFonts.inter(
                          color: const Color(0xFF94A3B8), fontSize: 12)),
                  const SizedBox(height: 8),
                  Row(
                    children: ['High', 'Medium', 'Low'].map((p) {
                      Color pColor;
                      switch (p) {
                        case 'High':
                          pColor = Colors.redAccent;
                          break;
                        case 'Medium':
                          pColor = Colors.orangeAccent;
                          break;
                        default:
                          pColor = Colors.greenAccent;
                      }
                      final isSelected = priority == p;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () => setDialogState(() => priority = p),
                          child: Container(
                            margin: const EdgeInsets.only(right: 8),
                            padding:
                                const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? pColor.withOpacity(0.15)
                                  : Colors.white.withOpacity(0.04),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: isSelected
                                      ? pColor.withOpacity(0.5)
                                      : Colors.white.withOpacity(0.08)),
                            ),
                            child: Center(
                              child: Text(p,
                                  style: GoogleFonts.inter(
                                      color: isSelected
                                          ? pColor
                                          : Colors.white54,
                                      fontSize: 12,
                                      fontWeight: isSelected
                                          ? FontWeight.bold
                                          : FontWeight.normal)),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),
                  // Time picker
                  GestureDetector(
                    onTap: () async {
                      final picked = await showTimePicker(
                        context: context,
                        initialTime: scheduledTime,
                        builder: (context, child) => Theme(
                          data: ThemeData.dark().copyWith(
                            colorScheme: const ColorScheme.dark(
                              primary: Colors.blueAccent,
                            ),
                          ),
                          child: child!,
                        ),
                      );
                      if (picked != null) {
                        setDialogState(() => scheduledTime = picked);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.04),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white.withOpacity(0.08)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.access_time_rounded,
                              color: Colors.blueAccent, size: 18),
                          const SizedBox(width: 10),
                          Text('Scheduled: ${scheduledTime.format(context)}',
                              style: GoogleFonts.inter(
                                  color: Colors.white70, fontSize: 13)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          style: TextButton.styleFrom(
                              foregroundColor: Colors.white54),
                          child: const Text('Cancel'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: GlowButton(
                          onPressed: () {
                            if (taskController.text.trim().isEmpty) return;
                            final now = DateTime.now();
                            final task = DailyTask(
                              id:
                                  'DT-${DateTime.now().millisecondsSinceEpoch}',
                              ticketId: ticketController.text.trim().isEmpty
                                  ? 'N/A'
                                  : ticketController.text.trim(),
                              customerName:
                                  customerController.text.trim().isEmpty
                                      ? 'Walk-in'
                                      : customerController.text.trim(),
                              deviceName: deviceController.text.trim().isEmpty
                                  ? 'Unknown Device'
                                  : deviceController.text.trim(),
                              taskDescription: taskController.text.trim(),
                              priority: priority,
                              isCompleted: false,
                              scheduledTime: DateTime(
                                now.year,
                                now.month,
                                now.day,
                                scheduledTime.hour,
                                scheduledTime.minute,
                              ),
                            );
                            MockDatabase.instance.addDailyTask(_techId, task);
                            Navigator.pop(context);
                          },
                          text: 'Add Task',
                          height: 44,
                          gradientColors: const [
                            Colors.blueAccent,
                            Color(0xFF1D4ED8)
                          ],
                          shadowColor: Colors.blueAccent,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _dialogField(
    TextEditingController ctrl,
    String hint,
    IconData icon, {
    int maxLines = 1,
  }) {
    return TextField(
      controller: ctrl,
      maxLines: maxLines,
      style: const TextStyle(color: Colors.white, fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white30, fontSize: 13),
        prefixIcon: Icon(icon, color: Colors.white30, size: 18),
        filled: true,
        fillColor: Colors.white.withOpacity(0.04),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: Colors.blueAccent, width: 1.5),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final tech = _tech;
    final tasks = tech.dailyTasks;
    final completed = tasks.where((t) => t.isCompleted).length;
    final progress = tasks.isEmpty ? 0.0 : completed / tasks.length;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTaskDialog,
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.add_rounded, color: Colors.white),
      ),
      body: Stack(
        children: [
          Positioned(
            top: -60,
            right: -60,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.blueAccent.withOpacity(0.06),
                boxShadow: [
                  BoxShadow(
                      color: Colors.blueAccent.withOpacity(0.06),
                      blurRadius: 100,
                      spreadRadius: 40),
                ],
              ),
            ),
          ),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                  child: _buildHeader(tech),
                ),

                // Progress card
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                  child: _buildProgressCard(tech, completed, tasks.length, progress),
                ),

                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Today's Tasks",
                          style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      Text('${tasks.length} total',
                          style: GoogleFonts.inter(
                              color: const Color(0xFF64748B), fontSize: 12)),
                    ],
                  ),
                ),

                Expanded(
                  child: tasks.isEmpty
                      ? _buildEmpty()
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                          physics: const BouncingScrollPhysics(),
                          itemCount: tasks.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 10),
                          itemBuilder: (context, i) =>
                              _buildTaskCard(tech.id, tasks[i], i),
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(Technician tech) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white70, size: 18),
          ),
        ),
        const SizedBox(width: 14),
        CircleAvatar(
          radius: 20,
          backgroundImage: NetworkImage(tech.imageUrl),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${tech.name.split(' ').first}\'s Task List',
                  style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.bold)),
              Text('Daily work assignments',
                  style: GoogleFonts.inter(
                      color: const Color(0xFF64748B), fontSize: 12)),
            ],
          ),
        ),
      ],
    ).animate().fade(duration: 400.ms).slideY(begin: -0.1);
  }

  Widget _buildProgressCard(
      Technician tech, int done, int total, double progress) {
    return GlassCard(
      opacity: 0.07,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Daily Progress',
                  style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold)),
              Text('$done / $total completed',
                  style: GoogleFonts.inter(
                      color: Colors.blueAccent,
                      fontSize: 12,
                      fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.white.withOpacity(0.05),
              color: progress == 1.0 ? Colors.greenAccent : Colors.blueAccent,
              minHeight: 8,
            ),
          ),
          const SizedBox(height: 10),
          if (progress == 1.0)
            Row(
              children: [
                const Icon(Icons.celebration_rounded,
                    color: Colors.greenAccent, size: 14),
                const SizedBox(width: 6),
                Text('All tasks completed for today! 🎉',
                    style: GoogleFonts.inter(
                        color: Colors.greenAccent,
                        fontSize: 12,
                        fontWeight: FontWeight.w600)),
              ],
            )
          else
            Text(
              '${((1 - progress) * 100).toInt()}% remaining — keep going!',
              style: GoogleFonts.inter(
                  color: const Color(0xFF64748B), fontSize: 11),
            ),
        ],
      ),
    ).animate().fade(duration: 500.ms, delay: 100.ms);
  }

  Widget _buildTaskCard(String techId, DailyTask task, int index) {
    Color priorityColor;
    IconData priorityIcon;
    switch (task.priority) {
      case 'High':
        priorityColor = Colors.redAccent;
        priorityIcon = Icons.priority_high_rounded;
        break;
      case 'Medium':
        priorityColor = Colors.orangeAccent;
        priorityIcon = Icons.remove_rounded;
        break;
      default:
        priorityColor = Colors.greenAccent;
        priorityIcon = Icons.arrow_downward_rounded;
    }

    final timeStr =
        '${task.scheduledTime.hour.toString().padLeft(2, '0')}:${task.scheduledTime.minute.toString().padLeft(2, '0')}';

    return GestureDetector(
      onTap: () => MockDatabase.instance.toggleDailyTask(techId, task.id),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: task.isCompleted
              ? Colors.greenAccent.withOpacity(0.05)
              : Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: task.isCompleted
                ? Colors.greenAccent.withOpacity(0.2)
                : Colors.white.withOpacity(0.07),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Checkbox
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 22,
              height: 22,
              margin: const EdgeInsets.only(top: 2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: task.isCompleted
                    ? Colors.greenAccent.withOpacity(0.2)
                    : Colors.transparent,
                border: Border.all(
                  color: task.isCompleted
                      ? Colors.greenAccent
                      : Colors.white24,
                  width: 1.5,
                ),
              ),
              child: task.isCompleted
                  ? const Icon(Icons.check_rounded,
                      color: Colors.greenAccent, size: 14)
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header row
                  Row(
                    children: [
                      Text(task.ticketId,
                          style: GoogleFonts.outfit(
                              color: task.isCompleted
                                  ? const Color(0xFF475569)
                                  : const Color(0xFFA78BFA),
                              fontSize: 11,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: priorityColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(priorityIcon,
                                size: 9, color: priorityColor),
                            const SizedBox(width: 3),
                            Text(task.priority,
                                style: TextStyle(
                                    color: priorityColor,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Row(
                        children: [
                          Icon(Icons.access_time_rounded,
                              size: 11, color: const Color(0xFF475569)),
                          const SizedBox(width: 3),
                          Text(timeStr,
                              style: GoogleFonts.inter(
                                  color: const Color(0xFF475569),
                                  fontSize: 10)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  // Device & customer
                  Text(task.deviceName,
                      style: GoogleFonts.outfit(
                          color: task.isCompleted
                              ? Colors.white38
                              : Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          decoration: task.isCompleted
                              ? TextDecoration.lineThrough
                              : null)),
                  Text(task.customerName,
                      style: GoogleFonts.inter(
                          color: const Color(0xFF64748B), fontSize: 11)),
                  const SizedBox(height: 8),
                  // Description
                  Text(task.taskDescription,
                      style: GoogleFonts.inter(
                          color: task.isCompleted
                              ? const Color(0xFF475569)
                              : const Color(0xFF94A3B8),
                          fontSize: 12,
                          height: 1.5)),
                ],
              ),
            ),
          ],
        ),
      ),
    )
        .animate(delay: (index * 60).ms)
        .fade(duration: 350.ms)
        .slideX(begin: 0.05);
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.checklist_rounded, color: Colors.white24, size: 52),
          const SizedBox(height: 16),
          Text('No Tasks Assigned Yet',
              style: GoogleFonts.outfit(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 17,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text("Tap the + button to add today's first task.",
              style: GoogleFonts.inter(color: Colors.white30, fontSize: 13)),
        ],
      ),
    );
  }
}
