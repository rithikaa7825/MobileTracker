import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/glow_button.dart';
import 'login_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A), // Slate 900
      body: Stack(
        children: [
          // Background blobs
          Positioned(
            top: -100,
            right: -100,
            child: _GlowingBlob(
              size: 300,
              color: const Color(0xFF6366F1).withOpacity(0.2), // Indigo
            ),
          ),
          Positioned(
            bottom: -50,
            left: -100,
            child: _GlowingBlob(
              size: 350,
              color: const Color(0xFF06B6D4).withOpacity(0.18), // Cyan
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height * 0.4,
            right: -50,
            child: _GlowingBlob(
              size: 200,
              color: const Color(0xFFD946EF).withOpacity(0.15), // Fuchsia
            ),
          ),

          // Main content
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 550),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                  const SizedBox(height: 20),
                  // App Logo & Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF6366F1).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: const Color(0xFF6366F1).withOpacity(0.3),
                            width: 1.5,
                          ),
                        ),
                        child: const Icon(
                          Icons.build_circle_rounded,
                          color: Color(0xFF818CF8),
                          size: 32,
                        ),
                      )
                          .animate()
                          .fade(duration: 800.ms)
                          .scale(delay: 100.ms, duration: 600.ms, curve: Curves.easeOutBack),
                      const SizedBox(width: 12),
                      Text(
                        'MobiTracker',
                        style: GoogleFonts.outfit(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0,
                        ),
                      )
                          .animate()
                          .fade(duration: 800.ms, delay: 200.ms)
                          .slideX(begin: 0.2, curve: Curves.easeOutQuad),
                    ],
                  ),
                  const Spacer(),

                  // Featured Artwork/Hero Section
                  Center(
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Outer glowing circle
                        Container(
                          width: 260,
                          height: 260,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFF6366F1).withOpacity(0.1),
                              width: 2,
                            ),
                          ),
                        )
                            .animate(onPlay: (controller) => controller.repeat(reverse: true))
                            .scale(duration: 3.seconds, curve: Curves.easeInOut),
                        // Middle dashed circle
                        Container(
                          width: 220,
                          height: 220,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFF06B6D4).withOpacity(0.15),
                              width: 1.5,
                            ),
                          ),
                        )
                            .animate(onPlay: (controller) => controller.repeat())
                            .rotate(duration: 20.seconds),

                        // Center Core Glass Card
                        GlassCard(
                          width: 170,
                          height: 170,
                          borderRadius: BorderRadius.circular(100),
                          padding: EdgeInsets.zero,
                          opacity: 0.12,
                          child: const Center(
                            child: Icon(
                              Icons.construction_rounded,
                              color: Color(0xFF818CF8),
                              size: 72,
                            ),
                          ),
                        )
                            .animate()
                            .fade(duration: 1.seconds, delay: 400.ms)
                            .scale(curve: Curves.elasticOut, duration: 1200.ms),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // Text Info
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Smart Shop Service\nManagement',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.outfit(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.w800,
                          height: 1.2,
                        ),
                      )
                          .animate()
                          .fade(duration: 800.ms, delay: 500.ms)
                          .slideY(begin: 0.1, curve: Curves.easeOut),
                      const SizedBox(height: 16),
                      Text(
                        'Seamlessly connect Customers, Technicians, and Administrators in one unified service ecosystem.',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.inter(
                          color: const Color(0xFF94A3B8),
                          fontSize: 15,
                          height: 1.5,
                        ),
                      )
                          .animate()
                          .fade(duration: 800.ms, delay: 700.ms)
                          .slideY(begin: 0.1, curve: Curves.easeOut),
                    ],
                  ),

                  const SizedBox(height: 40),

                  // Get Started Button
                  GlowButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const LoginScreen(),
                        ),
                      );
                    },
                    text: 'Get Started',
                    icon: Icons.arrow_forward_rounded,
                    gradientColors: const [
                      Color(0xFF6366F1), // Indigo
                      Color(0xFF4F46E5),
                    ],
                    shadowColor: const Color(0xFF6366F1),
                  )
                      .animate()
                      .fade(duration: 800.ms, delay: 900.ms)
                      .slideY(begin: 0.2, curve: Curves.fastLinearToSlowEaseIn),

                  const SizedBox(height: 24),

                  // Footer info
                  Text(
                    '© 2026 MobiTracker App. All rights reserved.',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.inter(
                      color: const Color(0xFF475569),
                      fontSize: 12,
                    ),
                  )
                      .animate()
                      .fade(duration: 1.seconds, delay: 1100.ms),
                  const SizedBox(height: 10),
                ],
              ),
            ),
          ),
        ),
      ),
    ],
      ),
    );
  }
}

class _GlowingBlob extends StatelessWidget {
  final double size;
  final Color color;

  const _GlowingBlob({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [
          BoxShadow(
            color: color,
            blurRadius: size * 0.4,
            spreadRadius: size * 0.2,
          ),
        ],
      ),
    );
  }
}
