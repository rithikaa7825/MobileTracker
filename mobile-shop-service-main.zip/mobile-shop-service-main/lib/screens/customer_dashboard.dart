import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/glow_button.dart';
import '../widgets/custom_text_field.dart';
import 'login_screen.dart';

import '../data/mock_database.dart';
import '../models/customer.dart';
import '../models/repair_ticket.dart';

class CustomerDashboard extends StatefulWidget {
  final String email;
  const CustomerDashboard({super.key, required this.email});

  @override
  State<CustomerDashboard> createState() => _CustomerDashboardState();
}

class _CustomerDashboardState extends State<CustomerDashboard> {
  @override
  void initState() {
    super.initState();
    MockDatabase.instance.addListener(_onDatabaseChanged);
    // Initial check
    WidgetsBinding.instance.addPostFrameCallback((_) => _onDatabaseChanged());
  }

  @override
  void dispose() {
    MockDatabase.instance.removeListener(_onDatabaseChanged);
    super.dispose();
  }

  void _onDatabaseChanged() {
    if (!mounted) return;
    final exists = MockDatabase.instance.customers.any(
      (c) => c.email.toLowerCase() == widget.email.toLowerCase()
    );
    if (!exists) {
      // Customer has been deleted by admin
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
        (route) => false,
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.redAccent,
          content: Row(
            children: [
              const Icon(Icons.error_outline_rounded, color: Colors.white),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Your account has been deleted or deactivated by the administrator.',
                  style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white),
                ),
              ),
            ],
          ),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } else {
      setState(() {});
    }
  }

  void _bookRepairDialog() {
    final deviceController = TextEditingController();
    final issueController = TextEditingController();
    final _formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          opacity: 0.16,
          color: Colors.black,
          borderRadius: BorderRadius.circular(24.0),
          border: Border.all(
            color: const Color(0xFFF43F5E).withOpacity(0.2),
            width: 1.5,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Request Repair',
                      style: GoogleFonts.outfit(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white, size: 20),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Book a new repair ticket. We will assign a technician immediately.',
                  style: GoogleFonts.inter(
                    color: const Color(0xFF94A3B8),
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 20),
                CustomTextField(
                  controller: deviceController,
                  labelText: 'Device Name / Model',
                  hintText: 'e.g. iPad Air 5th Gen',
                  prefixIcon: Icons.devices_other_rounded,
                  focusColor: const Color(0xFFF43F5E),
                  validator: (v) => v == null || v.isEmpty ? 'Device name is required' : null,
                ),
                const SizedBox(height: 16),
                CustomTextField(
                  controller: issueController,
                  labelText: 'Describe the Issue',
                  hintText: 'e.g. Screen cracked, battery draining fast',
                  prefixIcon: Icons.error_outline_rounded,
                  focusColor: const Color(0xFFF43F5E),
                  validator: (v) => v == null || v.isEmpty ? 'Please describe the issue' : null,
                ),
                const SizedBox(height: 24),
                GlowButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      final customer = MockDatabase.instance.customers.firstWhere(
                        (c) => c.email.toLowerCase() == widget.email.toLowerCase(),
                      );
                      final newTicket = RepairTicket(
                        id: '#${1000 + MockDatabase.instance.tickets.length + 1}',
                        customerId: customer.id,
                        customerName: customer.name,
                        customerPhone: customer.phone,
                        brand: 'Device',
                        model: deviceController.text,
                        imei: 'SN-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}',
                        issue: issueController.text,
                        status: 'Pending',
                        subStatus: 'Received',
                        progress: 0.25,
                        serviceDate: DateTime.now(),
                        deliveryDate: DateTime.now().add(const Duration(days: 3)),
                        warranty: '3 Months',
                        techName: 'Assigning Tech...',
                      );
                      MockDatabase.instance.addTicket(newTicket);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          backgroundColor: const Color(0xFFF43F5E),
                          content: const Text('Repair ticket booked successfully!'),
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      );
                    }
                  },
                  text: 'Submit Request',
                  icon: Icons.assignment_turned_in_rounded,
                  gradientColors: const [Color(0xFFF43F5E), Color(0xFFE11D48)],
                  shadowColor: const Color(0xFFF43F5E),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openChatDialog() {
    final chatController = TextEditingController();
    final List<Map<String, dynamic>> messages = [
      {'sender': 'bot', 'text': 'Hi Lisa! I am your AI repair assistant. How can I help you today?'},
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0F172A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.6,
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Chat header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFF43F5E)),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'Live Support Chat',
                              style: GoogleFonts.outfit(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.white, size: 20),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const Divider(color: Colors.white10),

                    // Chat messages list
                    Expanded(
                      child: ListView.builder(
                        physics: const BouncingScrollPhysics(),
                        itemCount: messages.length,
                        itemBuilder: (context, index) {
                          final msg = messages[index];
                          final isUser = msg['sender'] == 'user';
                          return Align(
                            alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 6),
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                color: isUser ? const Color(0xFFF43F5E) : Colors.white.withOpacity(0.06),
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(16),
                                  topRight: const Radius.circular(16),
                                  bottomLeft: isUser ? const Radius.circular(16) : Radius.zero,
                                  bottomRight: isUser ? Radius.zero : const Radius.circular(16),
                                ),
                              ),
                              child: Text(
                                msg['text'],
                                style: GoogleFonts.inter(color: Colors.white, fontSize: 13),
                              ),
                            ),
                          );
                        },
                      ),
                    ),

                    // Input row
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: chatController,
                            style: const TextStyle(color: Colors.white, fontSize: 14),
                            decoration: InputDecoration(
                              hintText: 'Type your message...',
                              hintStyle: TextStyle(color: Colors.white30, fontSize: 14),
                              filled: true,
                              fillColor: Colors.white.withOpacity(0.04),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: const BorderSide(color: Color(0xFFF43F5E)),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFF43F5E)),
                            child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                          ),
                          onPressed: () {
                            if (chatController.text.trim().isNotEmpty) {
                              final text = chatController.text;
                              setModalState(() {
                                messages.add({'sender': 'user', 'text': text});
                                chatController.clear();
                              });

                              // Simulated bot reply
                              Future.delayed(const Duration(milliseconds: 1200), () {
                                if (context.mounted) {
                                  setModalState(() {
                                    messages.add({
                                      'sender': 'bot',
                                      'text': 'I have registered your inquiry regarding "$text". An administrator will review this shortly!'
                                    });
                                  });
                                }
                              });
                            }
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          // Background glow
          Positioned(
            bottom: -80,
            right: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFF43F5E).withOpacity(0.08),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFF43F5E).withOpacity(0.08),
                    blurRadius: 100,
                    spreadRadius: 40,
                  )
                ],
              ),
            ),
          ),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 650),
              child: SafeArea(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 16),
                      _buildHeader(),
                      const SizedBox(height: 24),

                      // Service tracking
                      Text(
                        'Track Active Repair',
                        style: GoogleFonts.outfit(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      _buildRepairTrackerCard(),

                      const SizedBox(height: 24),

                      // Quick Actions Grid
                      Row(
                        children: [
                          Expanded(
                            child: _buildQuickActionCard(
                              'Book Repair',
                              'Request service details',
                              Icons.build_circle_outlined,
                              const Color(0xFFF43F5E),
                              _bookRepairDialog,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: _buildQuickActionCard(
                              'Support Chat',
                              'Talk to service AI',
                              Icons.chat_bubble_outline_rounded,
                              Colors.cyanAccent,
                              _openChatDialog,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 28),

                      // My Devices list
                      Text(
                        'My Registered Devices',
                        style: GoogleFonts.outfit(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      _buildDevicesList(),

                      const SizedBox(height: 28),

                      // Past Bills list
                      Text(
                        'Past Receipts & Billing',
                        style: GoogleFonts.outfit(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      _buildInvoicesList(),

                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    final customer = MockDatabase.instance.customers.firstWhere(
      (c) => c.email.toLowerCase() == widget.email.toLowerCase(),
      orElse: () => Customer(id: '', name: 'Valued Customer', email: widget.email, phone: ''),
    );

    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFFF43F5E), width: 2),
          ),
          child: const CircleAvatar(
            radius: 24,
            backgroundImage: NetworkImage('https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=256'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Hello, ${customer.name}',
                style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Customer Premium Tier',
                style: GoogleFonts.inter(
                  color: const Color(0xFFFDA4AF),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        IconButton(
          icon: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.logout_rounded, color: Colors.redAccent, size: 20),
          ),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const LoginScreen()),
            );
          },
        ),
      ],
    ).animate().fade(duration: 500.ms).slideY(begin: -0.1);
  }

  Widget _buildRepairTrackerCard() {
    final customer = MockDatabase.instance.customers.firstWhere(
      (c) => c.email.toLowerCase() == widget.email.toLowerCase(),
      orElse: () => Customer(id: '', name: 'Valued Customer', email: widget.email, phone: ''),
    );
    final activeTickets = MockDatabase.instance.tickets.where(
      (t) => t.customerId == customer.id && t.status != 'Delivered'
    ).toList();

    if (activeTickets.isEmpty) {
      return GlassCard(
        opacity: 0.08,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.build_circle_outlined, color: const Color(0xFFF43F5E).withOpacity(0.6), size: 40),
              const SizedBox(height: 12),
              Text(
                'No Active Repair Requests',
                style: GoogleFonts.outfit(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Text(
                'Need something fixed? Request a repair below to get started.',
                textAlign: TextAlign.center,
                style: GoogleFonts.inter(color: const Color(0xFF94A3B8), fontSize: 12),
              ),
            ],
          ),
        ),
      );
    }

    final ticket = activeTickets.first;
    final steps = ['Received', 'Diagnosing', 'Repairing', 'Ready'];
    String lookupStatus = ticket.subStatus;
    if (lookupStatus == 'Testing') {
      lookupStatus = 'Repairing';
    } else if (lookupStatus == 'Ready for PickUp' || ticket.status == 'Completed') {
      lookupStatus = 'Ready';
    }
    int currentStepIndex = steps.indexOf(lookupStatus);
    if (currentStepIndex == -1) {
      currentStepIndex = 0;
    }

    return GlassCard(
      opacity: 0.08,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      ticket.model,
                      style: GoogleFonts.outfit(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      'Assigned Tech: ${ticket.techName}',
                      style: GoogleFonts.inter(color: const Color(0xFF94A3B8), fontSize: 12),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFF43F5E).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFFF43F5E).withOpacity(0.3)),
                ),
                child: Text(
                  ticket.subStatus.toUpperCase(),
                  style: GoogleFonts.inter(color: const Color(0xFFFDA4AF), fontSize: 11, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Horizontal Progress steps
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(steps.length, (index) {
              bool isDone = index <= currentStepIndex;
              bool isActive = index == currentStepIndex;

              return Expanded(
                child: Row(
                  children: [
                    // Node
                    Column(
                      children: [
                        Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isDone ? const Color(0xFFF43F5E) : Colors.black.withOpacity(0.2),
                            border: Border.all(
                              color: isDone ? const Color(0xFFF43F5E) : Colors.white24,
                            ),
                          ),
                          child: Center(
                            child: isDone
                                ? const Icon(Icons.check, color: Colors.white, size: 12)
                                : null,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          steps[index],
                          style: GoogleFonts.inter(
                            color: isActive ? Colors.white : const Color(0xFF64748B),
                            fontSize: 10,
                            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                    // Line connector
                    if (index < steps.length - 1)
                      Expanded(
                        child: Container(
                          height: 2,
                          color: index < currentStepIndex
                              ? const Color(0xFFF43F5E)
                              : Colors.white.withOpacity(0.1),
                          margin: const EdgeInsets.only(bottom: 16),
                        ),
                      ),
                  ],
                ),
              );
            }),
          ),
        ],
      ),
    ).animate().fade(duration: 500.ms, delay: 200.ms);
  }

  Widget _buildQuickActionCard(String title, String desc, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: GlassCard(
        padding: const EdgeInsets.all(16),
        opacity: 0.08,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(height: 14),
            Text(
              title,
              style: GoogleFonts.outfit(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 2),
            Text(
              desc,
              style: GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDevicesList() {
    final customer = MockDatabase.instance.customers.firstWhere(
      (c) => c.email.toLowerCase() == widget.email.toLowerCase(),
      orElse: () => Customer(id: '', name: 'Valued Customer', email: widget.email, phone: ''),
    );
    final tickets = MockDatabase.instance.tickets.where((t) => t.customerId == customer.id).toList();

    if (tickets.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20.0),
          child: Text(
            'No registered devices yet.',
            style: GoogleFonts.inter(color: Colors.white30, fontSize: 13),
          ),
        ),
      );
    }

    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: tickets.length,
      separatorBuilder: (context, index) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final ticket = tickets[index];
        final isCompleted = ticket.status == 'Delivered' || ticket.status == 'Completed';
        final statusColor = isCompleted ? Colors.greenAccent : const Color(0xFFF43F5E);
        
        return GlassCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          opacity: 0.06,
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.laptop_mac_rounded, color: Colors.white60, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      ticket.model,
                      style: GoogleFonts.outfit(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      ticket.imei.isNotEmpty && ticket.imei != 'N/A' ? 'SN: ${ticket.imei}' : 'SN: Unknown',
                      style: GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 11),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  ticket.status,
                  style: GoogleFonts.inter(color: statusColor, fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInvoicesList() {
    final customer = MockDatabase.instance.customers.firstWhere(
      (c) => c.email.toLowerCase() == widget.email.toLowerCase(),
      orElse: () => Customer(id: '', name: 'Valued Customer', email: widget.email, phone: ''),
    );
    final completedTickets = MockDatabase.instance.tickets
        .where((t) => t.customerId == customer.id && (t.status == 'Delivered' || t.status == 'Completed'))
        .toList();

    if (completedTickets.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20.0),
          child: Text(
            'No billing history yet.',
            style: GoogleFonts.inter(color: Colors.white30, fontSize: 13),
          ),
        ),
      );
    }

    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: completedTickets.length,
      separatorBuilder: (context, index) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final ticket = completedTickets[index];
        final amount = ticket.warranty == 'None' ? '\$85.00' : '\$189.00';
        return GlassCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          opacity: 0.06,
          child: Row(
            children: [
              const Icon(Icons.receipt_long_rounded, color: Color(0xFFF43F5E), size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${ticket.model} Service',
                      style: GoogleFonts.outfit(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'INV-${ticket.id.replaceAll('#', '')} • Recently',
                      style: GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 11),
                    ),
                  ],
                ),
              ),
              Text(
                amount,
                style: GoogleFonts.outfit(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        );
      },
    );
  }
}
