import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/glow_button.dart';
import '../widgets/custom_text_field.dart';

class ForgotPasswordScreen extends StatefulWidget {
  final Color primaryColor;
  final Color accentColor;
  final String initialEmail;
  final List<Color> bgGradient;

  const ForgotPasswordScreen({
    super.key,
    required this.primaryColor,
    required this.accentColor,
    required this.initialEmail,
    required this.bgGradient,
  });

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  int _currentStep = 1; // 1: Email, 2: OTP, 3: Reset, 4: Success
  final _emailController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  // OTP inputs
  final List<TextEditingController> _otpControllers = List.generate(4, (_) => TextEditingController());
  final List<FocusNode> _otpFocusNodes = List.generate(4, (_) => FocusNode());

  bool _isLoading = false;
  final _formKeyEmail = GlobalKey<FormState>();
  final _formKeyPassword = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _emailController.text = widget.initialEmail;
  }

  @override
  void dispose() {
    _emailController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    for (var controller in _otpControllers) {
      controller.dispose();
    }
    for (var node in _otpFocusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  void _nextStep() {
    setState(() {
      _currentStep++;
    });
  }

  void _prevStep() {
    if (_currentStep > 1) {
      setState(() {
        _currentStep--;
      });
    } else {
      Navigator.pop(context);
    }
  }

  void _sendVerificationCode() async {
    if (_formKeyEmail.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      // Simulate sending API request
      await Future.delayed(const Duration(milliseconds: 1500));

      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        _nextStep();
      }
    }
  }

  void _verifyOtp() async {
    // Check if OTP is fully filled
    String code = _otpControllers.map((c) => c.text).join();
    if (code.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter the full 4-digit code.'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    // Simulate OTP verification
    await Future.delayed(const Duration(seconds: 1));

    if (mounted) {
      setState(() {
        _isLoading = false;
      });
      _nextStep();
    }
  }

  void _submitNewPassword() async {
    if (_formKeyPassword.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      // Simulate password update
      await Future.delayed(const Duration(milliseconds: 1500));

      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        _nextStep();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: widget.bgGradient,
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Stack(
          children: [
            // Blob background
            Positioned(
              bottom: -50,
              right: -50,
              child: Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.primaryColor.withOpacity(0.12),
                  boxShadow: [
                    BoxShadow(
                      color: widget.primaryColor.withOpacity(0.12),
                      blurRadius: 100,
                      spreadRadius: 50,
                    ),
                  ],
                ),
              ),
            ),

            SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 550),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                    // Back button / Header
                    if (_currentStep < 4)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
                            onPressed: _prevStep,
                          ),
                          Text(
                            'Password Recovery',
                            style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(width: 48), // Spacer balance
                        ],
                      ),

                    const SizedBox(height: 24),

                    // Progress indicators
                    if (_currentStep < 4) _buildProgressIndicator(),

                    const Spacer(),

                    // Step forms
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 500),
                      transitionBuilder: (child, animation) {
                        return SlideTransition(
                          position: Tween<Offset>(
                            begin: const Offset(0.2, 0.0),
                            end: Offset.zero,
                          ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic)),
                          child: FadeTransition(opacity: animation, child: child),
                        );
                      },
                      child: _buildCurrentStepWidget(),
                    ),

                    const Spacer(flex: 2),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
        ),
      ),
    );
  }

  Widget _buildProgressIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(3, (index) {
          int stepNum = index + 1;
          bool isCompleted = _currentStep > stepNum;
          bool isActive = _currentStep == stepNum;

          return Row(
            children: [
              // Circle node
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isCompleted
                      ? widget.primaryColor
                      : isActive
                          ? widget.primaryColor.withOpacity(0.2)
                          : Colors.black.withOpacity(0.25),
                  border: Border.all(
                    color: (isActive || isCompleted)
                        ? widget.primaryColor
                        : Colors.white.withOpacity(0.12),
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: isCompleted
                      ? const Icon(Icons.check_rounded, color: Colors.white, size: 16)
                      : Text(
                          '$stepNum',
                          style: TextStyle(
                            color: isActive ? widget.accentColor : Colors.white.withOpacity(0.5),
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                ),
              ),
              // Connecting line
              if (index < 2)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 50,
                  height: 2,
                  color: _currentStep > (stepNum)
                      ? widget.primaryColor
                      : Colors.white.withOpacity(0.12),
                ),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildCurrentStepWidget() {
    switch (_currentStep) {
      case 1:
        return _buildStepEmail();
      case 2:
        return _buildStepOTP();
      case 3:
        return _buildStepNewPassword();
      case 4:
      default:
        return _buildStepSuccess();
    }
  }

  Widget _buildStepEmail() {
    return GlassCard(
      key: const ValueKey('step-email'),
      opacity: 0.08,
      child: Form(
        key: _formKeyEmail,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.lock_reset_rounded, color: Colors.white, size: 48),
            const SizedBox(height: 16),
            Text(
              'Forgot Password',
              textAlign: TextAlign.center,
              style: GoogleFonts.outfit(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "No worries! Enter your email address and we'll send you a 4-digit code to reset your password.",
              textAlign: TextAlign.center,
              style: GoogleFonts.inter(
                color: const Color(0xFF94A3B8),
                fontSize: 14,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 24),
            CustomTextField(
              controller: _emailController,
              labelText: 'Email Address',
              hintText: 'yourname@example.com',
              prefixIcon: Icons.alternate_email_rounded,
              keyboardType: TextInputType.emailAddress,
              focusColor: widget.primaryColor,
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Email is required';
                }
                if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(val)) {
                  return 'Enter a valid email address';
                }
                return null;
              },
            ),
            const SizedBox(height: 24),
            GlowButton(
              onPressed: _sendVerificationCode,
              text: 'Send Code',
              icon: Icons.send_rounded,
              gradientColors: [widget.primaryColor, widget.primaryColor.withOpacity(0.8)],
              shadowColor: widget.primaryColor,
              isLoading: _isLoading,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepOTP() {
    return GlassCard(
      key: const ValueKey('step-otp'),
      opacity: 0.08,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.mark_email_read_outlined, color: Colors.white, size: 48),
          const SizedBox(height: 16),
          Text(
            'Verification Code',
            textAlign: TextAlign.center,
            style: GoogleFonts.outfit(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              style: GoogleFonts.inter(
                color: const Color(0xFF94A3B8),
                fontSize: 14,
                height: 1.4,
              ),
              children: [
                const TextSpan(text: 'We sent a 4-digit verification code to \n'),
                TextSpan(
                  text: _emailController.text,
                  style: TextStyle(color: widget.accentColor, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),

          // 4 OTP Boxes
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(4, (index) {
              return SizedBox(
                width: 58,
                height: 64,
                child: TextFormField(
                  controller: _otpControllers[index],
                  focusNode: _otpFocusNodes[index],
                  style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(1),
                    FilteringTextInputFormatter.digitsOnly,
                  ],
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.04),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16.0),
                      borderSide: BorderSide(
                        color: Colors.white.withOpacity(0.1),
                        width: 1.5,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16.0),
                      borderSide: BorderSide(
                        color: widget.primaryColor,
                        width: 2.0,
                      ),
                    ),
                  ),
                  onChanged: (value) {
                    if (value.isNotEmpty) {
                      if (index < 3) {
                        _otpFocusNodes[index + 1].requestFocus();
                      } else {
                        _otpFocusNodes[index].unfocus();
                        _verifyOtp(); // Auto-verify on final digit
                      }
                    } else {
                      if (index > 0) {
                        _otpFocusNodes[index - 1].requestFocus();
                      }
                    }
                  },
                ),
              );
            }),
          ),

          const SizedBox(height: 28),

          // Code filler suggestion
          InkWell(
            onTap: () {
              for (int i = 0; i < 4; i++) {
                _otpControllers[i].text = (i + 1).toString();
              }
              _verifyOtp();
            },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
              decoration: BoxDecoration(
                color: widget.primaryColor.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  'Auto-fill Demo Code (1234)',
                  style: TextStyle(color: widget.accentColor, fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ),

          const SizedBox(height: 24),
          GlowButton(
            onPressed: _verifyOtp,
            text: 'Verify Code',
            icon: Icons.verified_user_rounded,
            gradientColors: [widget.primaryColor, widget.primaryColor.withOpacity(0.8)],
            shadowColor: widget.primaryColor,
            isLoading: _isLoading,
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Didn't receive code? ",
                style: GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 13),
              ),
              TextButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('Verification code resent successfully.'),
                      backgroundColor: widget.primaryColor,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  );
                },
                style: TextButton.styleFrom(
                  foregroundColor: widget.accentColor,
                  padding: EdgeInsets.zero,
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: const Text('Resend code', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStepNewPassword() {
    return GlassCard(
      key: const ValueKey('step-new-password'),
      opacity: 0.08,
      child: Form(
        key: _formKeyPassword,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.shield_outlined, color: Colors.white, size: 48),
            const SizedBox(height: 16),
            Text(
              'Reset Password',
              textAlign: TextAlign.center,
              style: GoogleFonts.outfit(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Please create a strong new password that you do not use elsewhere.',
              textAlign: TextAlign.center,
              style: GoogleFonts.inter(
                color: const Color(0xFF94A3B8),
                fontSize: 14,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 24),
            CustomTextField(
              controller: _newPasswordController,
              labelText: 'New Password',
              hintText: 'Enter new password',
              prefixIcon: Icons.lock_outline_rounded,
              isPassword: true,
              focusColor: widget.primaryColor,
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'New password is required';
                }
                if (val.length < 6) {
                  return 'Must be at least 6 characters';
                }
                return null;
              },
            ),
            const SizedBox(height: 20),
            CustomTextField(
              controller: _confirmPasswordController,
              labelText: 'Confirm Password',
              hintText: 'Confirm new password',
              prefixIcon: Icons.lock_rounded,
              isPassword: true,
              focusColor: widget.primaryColor,
              textInputAction: TextInputAction.done,
              onFieldSubmitted: (_) => _submitNewPassword(),
              validator: (val) {
                if (val != _newPasswordController.text) {
                  return 'Passwords do not match';
                }
                return null;
              },
            ),
            const SizedBox(height: 24),
            GlowButton(
              onPressed: _submitNewPassword,
              text: 'Save Password',
              icon: Icons.check_circle_rounded,
              gradientColors: [widget.primaryColor, widget.primaryColor.withOpacity(0.8)],
              shadowColor: widget.primaryColor,
              isLoading: _isLoading,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepSuccess() {
    return GlassCard(
      key: const ValueKey('step-success'),
      opacity: 0.1,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.green.withOpacity(0.12),
              border: Border.all(color: Colors.greenAccent.withOpacity(0.4), width: 1.5),
            ),
            child: const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 54),
          )
              .animate()
              .scale(duration: 500.ms, curve: Curves.easeOutBack)
              .then()
              .shake(duration: 400.ms),
          const SizedBox(height: 20),
          Text(
            'Password Reset Complete',
            textAlign: TextAlign.center,
            style: GoogleFonts.outfit(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Your account password has been updated. You can now sign in with your new password.',
            textAlign: TextAlign.center,
            style: GoogleFonts.inter(
              color: const Color(0xFF94A3B8),
              fontSize: 14,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 32),
          GlowButton(
            onPressed: () {
              // Return to login screen
              Navigator.pop(context);
            },
            text: 'Back to Sign In',
            icon: Icons.arrow_back_rounded,
            gradientColors: const [Colors.green, Colors.greenAccent],
            shadowColor: Colors.green,
          ),
        ],
      ),
    );
  }
}
