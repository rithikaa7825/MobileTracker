import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/glow_button.dart';
import '../data/mock_database.dart';
import '../models/technician.dart';
import 'assign_technician_screen.dart';
import 'technician_work_status_screen.dart';
import 'daily_task_list_screen.dart';
import 'repair_notes_screen.dart';
import 'completion_report_screen.dart';

class TechnicianManagementScreen extends StatefulWidget {
  const TechnicianManagementScreen({super.key});

  @override
  State<TechnicianManagementScreen> createState() =>
      _TechnicianManagementScreenState();
}

class _TechnicianManagementScreenState
    extends State<TechnicianManagementScreen> {
  String _searchQuery = '';
  String _filterStatus = 'All';
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    MockDatabase.instance.addListener(_onDbChanged);
  }

  void _onDbChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    MockDatabase.instance.removeListener(_onDbChanged);
    _searchController.dispose();
    super.dispose();
  }

  List<Technician> get _filteredTechs {
    var list = MockDatabase.instance.technicians;
    if (_filterStatus != 'All') {
      list = list.where((t) => t.status == _filterStatus).toList();
    }
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list
          .where((t) =>
              t.name.toLowerCase().contains(q) ||
              t.role.toLowerCase().contains(q))
          .toList();
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final techs = _filteredTechs;
    final activeCount =
        MockDatabase.instance.technicians.where((t) => t.status == 'Active').length;
    final busyCount =
        MockDatabase.instance.technicians.where((t) => t.status == 'Busy').length;
    final offlineCount =
        MockDatabase.instance.technicians.where((t) => t.status == 'Offline').length;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          // Background glow
          Positioned(
            top: -60,
            right: -60,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF0D9488).withOpacity(0.07),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF0D9488).withOpacity(0.07),
                    blurRadius: 120,
                    spreadRadius: 50,
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: -80,
            left: -80,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF8B5CF6).withOpacity(0.05),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF8B5CF6).withOpacity(0.05),
                    blurRadius: 100,
                    spreadRadius: 40,
                  ),
                ],
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Header
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                      child: _buildHeader(),
                    ),

                    // Summary row
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                      child: _buildSummaryRow(activeCount, busyCount, offlineCount),
                    ),

                    // Quick Actions
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                      child: _buildQuickActions(),
                    ),

                    // Search + filter
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                      child: _buildSearchAndFilter(),
                    ),

                    const SizedBox(height: 16),

                    // Technician list
                    Expanded(
                      child: techs.isEmpty
                          ? _buildEmpty()
                          : ListView.separated(
                              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                              physics: const BouncingScrollPhysics(),
                              itemCount: techs.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 12),
                              itemBuilder: (context, i) =>
                                  _buildTechCard(techs[i], i),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white70, size: 18),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Technician Hub',
                style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Manage, assign & track your team',
                style: GoogleFonts.inter(
                  color: const Color(0xFF64748B),
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFF0D9488).withOpacity(0.12),
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFF0D9488).withOpacity(0.25)),
          ),
          child: const Icon(Icons.engineering_rounded,
              color: Color(0xFF2DD4BF), size: 20),
        ),
      ],
    ).animate().fade(duration: 500.ms).slideY(begin: -0.1);
  }

  Widget _buildSummaryRow(int active, int busy, int offline) {
    return Row(
      children: [
        _buildSummaryChip(
            'Active', active, const Color(0xFF0D9488), Icons.radio_button_on),
        const SizedBox(width: 10),
        _buildSummaryChip('Busy', busy, Colors.orangeAccent, Icons.hourglass_top_rounded),
        const SizedBox(width: 10),
        _buildSummaryChip('Offline', offline, const Color(0xFF475569), Icons.circle_outlined),
      ],
    ).animate().fade(duration: 500.ms, delay: 100.ms);
  }

  Widget _buildSummaryChip(String label, int count, Color color, IconData icon) {
    return Expanded(
      child: GlassCard(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
        opacity: 0.06,
        child: Row(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$count',
                  style: GoogleFonts.outfit(
                    color: color,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  label,
                  style: GoogleFonts.inter(
                      color: const Color(0xFF94A3B8), fontSize: 11),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            _buildActionTile(
              icon: Icons.person_add_alt_1_rounded,
              label: 'Assign\nTechnician',
              color: const Color(0xFF8B5CF6),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const AssignTechnicianScreen()),
              ),
            ),
            const SizedBox(width: 10),
            _buildActionTile(
              icon: Icons.track_changes_rounded,
              label: 'Work\nStatus',
              color: const Color(0xFF0D9488),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const TechnicianWorkStatusScreen()),
              ),
            ),
            const SizedBox(width: 10),
            _buildActionTile(
              icon: Icons.checklist_rounded,
              label: 'Daily\nTasks',
              color: Colors.blueAccent,
              onTap: () {
                final techs = MockDatabase.instance.technicians;
                if (techs.isNotEmpty) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => DailyTaskListScreen(
                            technician: techs.first)),
                  );
                }
              },
            ),
            const SizedBox(width: 10),
            _buildActionTile(
              icon: Icons.bar_chart_rounded,
              label: 'Reports',
              color: Colors.amberAccent,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const CompletionReportScreen()),
              ),
            ),
          ],
        ),
      ],
    ).animate().fade(duration: 500.ms, delay: 150.ms);
  }

  Widget _buildActionTile({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.2)),
          ),
          child: Column(
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(height: 6),
              Text(
                label,
                textAlign: TextAlign.center,
                style: GoogleFonts.inter(
                  color: Colors.white.withOpacity(0.85),
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  height: 1.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchAndFilter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'All Technicians',
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: GlassCard(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                opacity: 0.05,
                child: Row(
                  children: [
                    const Icon(Icons.search_rounded,
                        color: Color(0xFF94A3B8), size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        onChanged: (v) => setState(() => _searchQuery = v),
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        decoration: const InputDecoration(
                          hintText: 'Search by name or role...',
                          hintStyle:
                              TextStyle(color: Colors.white30, fontSize: 13),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            GestureDetector(
              onTap: () => _showAddTechnicianDialog(),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF0D9488).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: const Color(0xFF0D9488).withOpacity(0.3)),
                ),
                child: const Icon(Icons.person_add_alt_1_rounded,
                    color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: ['All', 'Active', 'Busy', 'Offline'].map((status) {
              final isSelected = _filterStatus == status;
              Color chipColor;
              switch (status) {
                case 'Active':
                  chipColor = const Color(0xFF0D9488);
                  break;
                case 'Busy':
                  chipColor = Colors.orangeAccent;
                  break;
                case 'Offline':
                  chipColor = const Color(0xFF475569);
                  break;
                default:
                  chipColor = const Color(0xFF8B5CF6);
              }
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: () => setState(() => _filterStatus = status),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? chipColor.withOpacity(0.15)
                          : Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected
                            ? chipColor.withOpacity(0.4)
                            : Colors.white.withOpacity(0.08),
                      ),
                    ),
                    child: Text(
                      status,
                      style: GoogleFonts.inter(
                        color: isSelected ? chipColor : const Color(0xFF94A3B8),
                        fontSize: 12,
                        fontWeight: isSelected
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    ).animate().fade(duration: 500.ms, delay: 200.ms);
  }

  Widget _buildTechCard(Technician tech, int index) {
    Color statusColor;
    Color statusBg;
    switch (tech.status) {
      case 'Active':
        statusColor = const Color(0xFF0D9488);
        statusBg = const Color(0xFF0D9488);
        break;
      case 'Busy':
        statusColor = Colors.orangeAccent;
        statusBg = Colors.orangeAccent;
        break;
      default:
        statusColor = const Color(0xFF475569);
        statusBg = const Color(0xFF475569);
    }

    return GestureDetector(
      onTap: () => _showTechActions(tech),
      child: GlassCard(
        padding: const EdgeInsets.all(16),
        opacity: 0.07,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 26,
                      backgroundImage: NetworkImage(tech.imageUrl),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: statusBg,
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: const Color(0xFF0F172A), width: 2),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tech.name,
                        style: GoogleFonts.outfit(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        tech.role,
                        style: GoogleFonts.inter(
                          color: const Color(0xFF94A3B8),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: statusColor.withOpacity(0.3)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 5,
                            height: 5,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle, color: statusColor),
                          ),
                          const SizedBox(width: 5),
                          Text(
                            tech.status,
                            style: GoogleFonts.inter(
                              color: statusColor,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Since ${tech.joinDate}',
                      style: GoogleFonts.inter(
                          color: const Color(0xFF475569), fontSize: 10),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 14),
            const Divider(color: Colors.white10, height: 1),
            const SizedBox(height: 12),
            Row(
              children: [
                _buildMiniStat(Icons.build_rounded,
                    '${tech.totalRepairs} Repairs', const Color(0xFFA78BFA)),
                const SizedBox(width: 16),
                _buildMiniStat(Icons.star_rounded,
                    '${(tech.successRate * 100).toInt()}% Rate', Colors.amberAccent),
                const SizedBox(width: 16),
                _buildMiniStat(
                    Icons.assignment_rounded,
                    '${tech.activeJobs} Active',
                    tech.activeJobs > 0
                        ? Colors.cyanAccent
                        : const Color(0xFF475569)),
              ],
            ),
            const SizedBox(height: 12),
            // Specializations
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: tech.specializations.map((s) {
                return Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.04),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Text(
                    s,
                    style: GoogleFonts.inter(
                        color: Colors.white60, fontSize: 10),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 14),
            // Action row
            Row(
              children: [
                _buildCardAction(
                  icon: Icons.checklist_rounded,
                  label: 'Tasks',
                  color: Colors.blueAccent,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) =>
                            DailyTaskListScreen(technician: tech)),
                  ),
                ),
                const SizedBox(width: 8),
                _buildCardAction(
                  icon: Icons.note_add_rounded,
                  label: 'Notes',
                  color: const Color(0xFF0D9488),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => RepairNotesScreen(technician: tech)),
                  ),
                ),
                const SizedBox(width: 8),
                _buildCardAction(
                  icon: Icons.assignment_turned_in_rounded,
                  label: 'Assign',
                  color: const Color(0xFF8B5CF6),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => AssignTechnicianScreen(
                            preSelectedTech: tech)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    )
        .animate(delay: (index * 60).ms)
        .fade(duration: 400.ms)
        .slideY(begin: 0.05);
  }

  Widget _buildMiniStat(IconData icon, String label, Color color) {
    return Row(
      children: [
        Icon(icon, size: 13, color: color),
        const SizedBox(width: 4),
        Text(
          label,
          style: GoogleFonts.inter(
              color: Colors.white60, fontSize: 11, fontWeight: FontWeight.w500),
        ),
      ],
    );
  }

  Widget _buildCardAction({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withOpacity(0.2)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 14, color: color),
              const SizedBox(width: 5),
              Text(
                label,
                style: GoogleFonts.inter(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.engineering_rounded, color: Colors.white24, size: 52),
          const SizedBox(height: 16),
          Text(
            'No Technicians Found',
            style: GoogleFonts.outfit(
                color: Colors.white.withOpacity(0.5),
                fontSize: 17,
                fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(
            'Try changing your search or filter.',
            style: GoogleFonts.inter(color: Colors.white30, fontSize: 13),
          ),
        ],
      ),
    );
  }

  void _showTechActions(Technician tech) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                      radius: 20,
                      backgroundImage: NetworkImage(tech.imageUrl)),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tech.name,
                          style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      Text(tech.role,
                          style: GoogleFonts.inter(
                              color: const Color(0xFF94A3B8), fontSize: 12)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Divider(color: Colors.white10),
              const SizedBox(height: 8),
              _buildSheetTile(Icons.person_add_alt_1_rounded,
                  'Assign to Ticket', const Color(0xFF8B5CF6), () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) =>
                            AssignTechnicianScreen(preSelectedTech: tech)));
              }),
              _buildSheetTile(Icons.track_changes_rounded, 'Update Work Status',
                  const Color(0xFF0D9488), () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const TechnicianWorkStatusScreen()));
              }),
              _buildSheetTile(Icons.checklist_rounded, 'View Daily Tasks',
                  Colors.blueAccent, () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => DailyTaskListScreen(technician: tech)));
              }),
              _buildSheetTile(Icons.note_add_rounded, 'Repair Notes',
                  Colors.cyanAccent, () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => RepairNotesScreen(technician: tech)));
              }),
              _buildSheetTile(Icons.bar_chart_rounded, 'Completion Report',
                  Colors.amberAccent, () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CompletionReportScreen()));
              }),
              _buildSheetTile(Icons.edit_rounded, 'Edit Details',
                  Colors.amberAccent, () {
                Navigator.pop(context);
                _showAddTechnicianDialog(technician: tech);
              }),
              _buildSheetTile(Icons.delete_forever_rounded, 'Delete Technician',
                  Colors.redAccent, () {
                Navigator.pop(context);
                _confirmDeleteTechnician(tech);
              }),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSheetTile(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 0, vertical: 2),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
      title: Text(
        label,
        style: GoogleFonts.inter(
            color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
      ),
      trailing: const Icon(Icons.arrow_forward_ios_rounded,
          color: Colors.white24, size: 14),
      onTap: onTap,
    );
  }

  void _showAddTechnicianDialog({Technician? technician}) {
    final isEdit = technician != null;
    final nameController = TextEditingController(text: isEdit ? technician.name : '');
    final roleController = TextEditingController(text: isEdit ? technician.role : '');
    final emailController = TextEditingController(text: isEdit ? technician.email : '');
    final phoneController = TextEditingController(text: isEdit ? technician.phone : '');
    final specController = TextEditingController(
        text: isEdit ? technician.specializations.join(', ') : '');
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: SingleChildScrollView(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: GlassCard(
              opacity: 0.16,
              color: Colors.black,
              borderRadius: BorderRadius.circular(24.0),
              border: Border.all(
                color: const Color(0xFF0D9488).withOpacity(0.25),
                width: 1.5,
              ),
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          isEdit ? 'Edit Technician' : 'Add Technician',
                          style: GoogleFonts.outfit(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.white, size: 20),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    CustomTextField(
                      controller: nameController,
                      labelText: 'Full Name',
                      hintText: 'e.g. John Doe',
                      prefixIcon: Icons.person_rounded,
                      focusColor: const Color(0xFF0D9488),
                      validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Name is required' : null,
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: roleController,
                      labelText: 'Role / Title',
                      hintText: 'e.g. Senior Hardware Specialist',
                      prefixIcon: Icons.badge_rounded,
                      focusColor: const Color(0xFF0D9488),
                      validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Role is required' : null,
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: emailController,
                      labelText: 'Email Address',
                      hintText: 'e.g. john.doe@mobitracker.com',
                      prefixIcon: Icons.alternate_email_rounded,
                      keyboardType: TextInputType.emailAddress,
                      focusColor: const Color(0xFF0D9488),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Email is required';
                        if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(v)) {
                          return 'Enter a valid email address';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: phoneController,
                      labelText: 'Mobile Number',
                      hintText: 'e.g. +1 (555) 012-3456',
                      prefixIcon: Icons.phone_android_rounded,
                      keyboardType: TextInputType.phone,
                      focusColor: const Color(0xFF0D9488),
                      validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Phone is required' : null,
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: specController,
                      labelText: 'Specializations (comma separated)',
                      hintText: 'e.g. iPhone, MacBook, Soldering',
                      prefixIcon: Icons.handyman_rounded,
                      focusColor: const Color(0xFF0D9488),
                    ),
                    const SizedBox(height: 24),
                    GlowButton(
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          final specs = specController.text
                              .split(',')
                              .map((s) => s.trim())
                              .where((s) => s.isNotEmpty)
                              .toList();
                          if (isEdit) {
                            final updated = technician.copyWith(
                              name: nameController.text.trim(),
                              role: roleController.text.trim(),
                              email: emailController.text.trim(),
                              phone: phoneController.text.trim(),
                              specializations: specs,
                            );
                            MockDatabase.instance.editTechnician(updated);
                          } else {
                            final newId = 'T-${DateTime.now().millisecondsSinceEpoch}';
                            final newTech = Technician(
                              id: newId,
                              name: nameController.text.trim(),
                              role: roleController.text.trim(),
                              email: emailController.text.trim(),
                              phone: phoneController.text.trim(),
                              imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=256',
                              status: 'Offline',
                              successRate: 0.95,
                              totalRepairs: 0,
                              activeJobs: 0,
                              joinDate: 'May 2026',
                              specializations: specs,
                            );
                            MockDatabase.instance.addTechnician(newTech);
                          }
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              backgroundColor: const Color(0xFF0D9488),
                              content: Text(isEdit
                                  ? 'Technician details updated successfully!'
                                  : 'New technician added successfully!'),
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          );
                        }
                      },
                      text: isEdit ? 'Save Changes' : 'Add Technician',
                      icon: isEdit ? Icons.check_circle_rounded : Icons.person_add_alt_1_rounded,
                      gradientColors: const [Color(0xFF0D9488), Color(0xFF0F766E)],
                      shadowColor: const Color(0xFF0D9488),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _confirmDeleteTechnician(Technician technician) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassCard(
          opacity: 0.16,
          color: Colors.black,
          borderRadius: BorderRadius.circular(24.0),
          border: Border.all(
            color: Colors.redAccent.withOpacity(0.2),
            width: 1.5,
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.redAccent.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 24),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Delete Technician',
                      style: GoogleFonts.outfit(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Are you sure you want to delete technician ${technician.name}? This action cannot be undone.',
                  style: GoogleFonts.inter(
                    color: const Color(0xFF94A3B8),
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.pop(context),
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white70,
                        ),
                        child: const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GlowButton(
                        onPressed: () {
                          MockDatabase.instance.deleteTechnician(technician.id);
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              backgroundColor: Colors.redAccent,
                              content: Text('Technician ${technician.name} deleted successfully!'),
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          );
                        },
                        text: 'Delete',
                        icon: Icons.delete_forever_rounded,
                        gradientColors: const [Colors.redAccent, Color(0xFFDC2626)],
                        shadowColor: Colors.redAccent,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
