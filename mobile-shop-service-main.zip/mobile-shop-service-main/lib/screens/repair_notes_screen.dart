import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/glow_button.dart';
import '../data/mock_database.dart';
import '../models/technician.dart';

class RepairNotesScreen extends StatefulWidget {
  final Technician technician;

  const RepairNotesScreen({super.key, required this.technician});

  @override
  State<RepairNotesScreen> createState() => _RepairNotesScreenState();
}

class _RepairNotesScreenState extends State<RepairNotesScreen> {
  late String _techId;

  @override
  void initState() {
    super.initState();
    _techId = widget.technician.id;
    MockDatabase.instance.addListener(_onDbChanged);
  }

  void _onDbChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    MockDatabase.instance.removeListener(_onDbChanged);
    super.dispose();
  }

  Technician get _tech =>
      MockDatabase.instance.getTechnicianById(_techId) ?? widget.technician;

  void _showAddNoteDialog() {
    final ticketController = TextEditingController();
    final deviceController = TextEditingController();
    final noteController = TextEditingController();

    // Pre-fill from active tickets for this tech
    final activeTickets =
        MockDatabase.instance.getTicketsForTechnician(widget.technician.name);

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          String? selectedTicketId;
          String? selectedDeviceName;

          return Dialog(
            backgroundColor: Colors.transparent,
            insetPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: GlassCard(
              opacity: 0.18,
              color: Colors.black,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                  color: const Color(0xFF0D9488).withOpacity(0.25)),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color(0xFF0D9488).withOpacity(0.12),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.note_add_rounded,
                              color: Color(0xFF2DD4BF), size: 22),
                        ),
                        const SizedBox(width: 12),
                        Text('Upload Repair Note',
                            style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Quick-fill from active tickets
                    if (activeTickets.isNotEmpty) ...[
                      Text('Quick Fill from Active Ticket',
                          style: GoogleFonts.inter(
                              color: const Color(0xFF64748B), fontSize: 11)),
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 36,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: activeTickets.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(width: 8),
                          itemBuilder: (context, i) {
                            final t = activeTickets[i];
                            final isSelected = selectedTicketId == t.id;
                            return GestureDetector(
                              onTap: () {
                                setDialogState(() {
                                  selectedTicketId = t.id;
                                  selectedDeviceName =
                                      '${t.brand} ${t.model}';
                                  ticketController.text = t.id;
                                  deviceController.text =
                                      '${t.brand} ${t.model}';
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? const Color(0xFF0D9488)
                                          .withOpacity(0.15)
                                      : Colors.white.withOpacity(0.04),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: isSelected
                                        ? const Color(0xFF0D9488)
                                            .withOpacity(0.4)
                                        : Colors.white.withOpacity(0.08),
                                  ),
                                ),
                                child: Text(
                                  '${t.id} · ${t.brand} ${t.model}',
                                  style: GoogleFonts.inter(
                                      color: isSelected
                                          ? const Color(0xFF2DD4BF)
                                          : Colors.white60,
                                      fontSize: 11),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],

                    _dialogField(ticketController, 'Ticket ID (e.g. #1093)',
                        Icons.tag_rounded),
                    const SizedBox(height: 12),
                    _dialogField(deviceController, 'Device Name',
                        Icons.smartphone_rounded),
                    const SizedBox(height: 12),
                    TextField(
                      controller: noteController,
                      maxLines: 5,
                      style: const TextStyle(color: Colors.white, fontSize: 13),
                      decoration: InputDecoration(
                        hintText:
                            'Describe findings, parts replaced, diagnostics...',
                        hintStyle: const TextStyle(
                            color: Colors.white24, fontSize: 12),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.04),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                              color: Colors.white.withOpacity(0.08)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                              color: Colors.white.withOpacity(0.08)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                              color: Color(0xFF0D9488), width: 1.5),
                        ),
                        contentPadding: const EdgeInsets.all(14),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: () => Navigator.pop(context),
                            style: TextButton.styleFrom(
                                foregroundColor: Colors.white54),
                            child: const Text('Cancel'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GlowButton(
                            onPressed: () {
                              if (noteController.text.trim().isEmpty) return;
                              final note = RepairNote(
                                id:
                                    'RN-${DateTime.now().millisecondsSinceEpoch}',
                                ticketId: ticketController.text.trim().isEmpty
                                    ? 'N/A'
                                    : ticketController.text.trim(),
                                deviceName:
                                    deviceController.text.trim().isEmpty
                                        ? 'Unknown Device'
                                        : deviceController.text.trim(),
                                content: noteController.text.trim(),
                                timestamp: DateTime.now(),
                                technicianId: _techId,
                              );
                              MockDatabase.instance.addRepairNote(_techId, note);
                              Navigator.pop(context);
                            },
                            text: 'Upload Note',
                            height: 44,
                            gradientColors: const [
                              Color(0xFF0D9488),
                              Color(0xFF0F766E)
                            ],
                            shadowColor: const Color(0xFF0D9488),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _dialogField(
      TextEditingController ctrl, String hint, IconData icon) {
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
        prefixIcon: Icon(icon, color: Colors.white30, size: 17),
        filled: true,
        fillColor: Colors.white.withOpacity(0.04),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: Color(0xFF0D9488), width: 1.5),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  @override
  Widget build(BuildContext context) {
    final tech = _tech;
    final notes = tech.repairNotes;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddNoteDialog,
        backgroundColor: const Color(0xFF0D9488),
        icon: const Icon(Icons.note_add_rounded, color: Colors.white),
        label: Text('Add Note',
            style: GoogleFonts.inter(
                color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: Stack(
        children: [
          Positioned(
            top: -60,
            left: -60,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF0D9488).withOpacity(0.06),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFF0D9488).withOpacity(0.06),
                      blurRadius: 100,
                      spreadRadius: 40),
                ],
              ),
            ),
          ),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                  child: _buildHeader(tech),
                ),

                // Stats
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                  child: _buildStatsRow(notes.length),
                ),

                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Repair Notes Log',
                          style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      Text('${notes.length} entries',
                          style: GoogleFonts.inter(
                              color: const Color(0xFF64748B), fontSize: 12)),
                    ],
                  ),
                ),

                Expanded(
                  child: notes.isEmpty
                      ? _buildEmpty()
                      : ListView.separated(
                          padding:
                              const EdgeInsets.fromLTRB(20, 0, 20, 100),
                          physics: const BouncingScrollPhysics(),
                          itemCount: notes.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 12),
                          itemBuilder: (context, i) =>
                              _buildNoteCard(notes[i], i),
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(Technician tech) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white70, size: 18),
          ),
        ),
        const SizedBox(width: 14),
        CircleAvatar(
            radius: 20, backgroundImage: NetworkImage(tech.imageUrl)),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Repair Notes',
                  style: GoogleFonts.outfit(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
              Text(tech.name,
                  style: GoogleFonts.inter(
                      color: const Color(0xFF2DD4BF), fontSize: 12,
                      fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ],
    ).animate().fade(duration: 400.ms).slideY(begin: -0.1);
  }

  Widget _buildStatsRow(int count) {
    final today = _tech.repairNotes
        .where((n) => DateTime.now().difference(n.timestamp).inHours < 24)
        .length;

    return Row(
      children: [
        _buildStatTile('${_tech.totalRepairs}', 'All Repairs',
            const Color(0xFFA78BFA), Icons.build_rounded),
        const SizedBox(width: 10),
        _buildStatTile('$count', 'Total Notes',
            const Color(0xFF0D9488), Icons.notes_rounded),
        const SizedBox(width: 10),
        _buildStatTile('$today', 'Today',
            Colors.amberAccent, Icons.today_rounded),
      ],
    ).animate().fade(duration: 500.ms, delay: 100.ms);
  }

  Widget _buildStatTile(
      String value, String label, Color color, IconData icon) {
    return Expanded(
      child: GlassCard(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        opacity: 0.06,
        child: Row(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value,
                    style: GoogleFonts.outfit(
                        color: color,
                        fontSize: 16,
                        fontWeight: FontWeight.bold)),
                Text(label,
                    style: GoogleFonts.inter(
                        color: const Color(0xFF64748B), fontSize: 10)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoteCard(RepairNote note, int index) {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      opacity: 0.07,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF0D9488).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                      color: const Color(0xFF0D9488).withOpacity(0.25)),
                ),
                child: Text(note.ticketId,
                    style: GoogleFonts.outfit(
                        color: const Color(0xFF2DD4BF),
                        fontSize: 11,
                        fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(note.deviceName,
                    style: GoogleFonts.outfit(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis),
              ),
              Row(
                children: [
                  const Icon(Icons.access_time_rounded,
                      size: 11, color: Color(0xFF475569)),
                  const SizedBox(width: 3),
                  Text(_timeAgo(note.timestamp),
                      style: GoogleFonts.inter(
                          color: const Color(0xFF475569), fontSize: 10)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(color: Colors.white10, height: 1),
          const SizedBox(height: 12),

          // Note content
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 3,
                height: 60,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF0D9488), Color(0xFF0D9488)],
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(note.content,
                    style: GoogleFonts.inter(
                        color: const Color(0xFF94A3B8),
                        fontSize: 13,
                        height: 1.6)),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Footer
          Row(
            children: [
              const Icon(Icons.verified_rounded,
                  size: 12, color: Color(0xFF0D9488)),
              const SizedBox(width: 5),
              Text('Logged by ${widget.technician.name}',
                  style: GoogleFonts.inter(
                      color: const Color(0xFF475569), fontSize: 10)),
              const Spacer(),
              Text(
                '${note.timestamp.day}/${note.timestamp.month}/${note.timestamp.year}',
                style: GoogleFonts.inter(
                    color: const Color(0xFF334155), fontSize: 10),
              ),
            ],
          ),
        ],
      ),
    )
        .animate(delay: (index * 60).ms)
        .fade(duration: 350.ms)
        .slideY(begin: 0.05);
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.note_outlined, color: Colors.white24, size: 52),
          const SizedBox(height: 16),
          Text('No Repair Notes Yet',
              style: GoogleFonts.outfit(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 17,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('Tap "Add Note" to log the first repair entry.',
              style: GoogleFonts.inter(color: Colors.white30, fontSize: 13)),
        ],
      ),
    );
  }
}
