import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/glow_button.dart';
import '../models/technician.dart';
import '../models/repair_ticket.dart';
import '../data/mock_database.dart';
import 'login_screen.dart';

class TechnicianDashboard extends StatefulWidget {
  final String email;
  const TechnicianDashboard({super.key, required this.email});

  @override
  State<TechnicianDashboard> createState() => _TechnicianDashboardState();
}

class _TechnicianDashboardState extends State<TechnicianDashboard> {
  int _activeTab = 0;
  String _techStatus = 'Online';
  Color _statusColor = const Color(0xFF0D9488); // Teal

  final List<String> _statusSequence = ['Received', 'Diagnosing', 'Repairing', 'Testing', 'Ready for PickUp', 'Delivered'];

  String _selectedActiveTicketId = '#1093';

  RepairTicket? get _activePriorityTicket {
    final tickets = MockDatabase.instance.tickets;
    final index = tickets.indexWhere((t) => t.id == _selectedActiveTicketId);
    if (index != -1) {
      return tickets[index];
    }
    return null;
  }

  String get _activeJobStatus {
    final t = _activePriorityTicket;
    return t != null ? t.subStatus : 'Diagnosing';
  }

  double get _activeJobProgress {
    final t = _activePriorityTicket;
    return t != null ? t.progress : 0.4;
  }

  String _getTicketPriority(String ticketId) {
    for (var tech in MockDatabase.instance.technicians) {
      for (var task in tech.dailyTasks) {
        if (task.ticketId == ticketId) {
          return task.priority;
        }
      }
    }
    if (ticketId == '#1093' || ticketId == '#1095') return 'High';
    if (ticketId == '#1094') return 'Medium';
    return 'Low';
  }

  Color _getPriorityColor(String priority) {
    switch (priority) {
      case 'High':
        return Colors.orangeAccent;
      case 'Medium':
        return Colors.blueAccent;
      case 'Low':
      default:
        return Colors.greenAccent;
    }
  }

  Technician get _currentTech {
    return MockDatabase.instance.technicians.firstWhere(
      (t) => t.email.toLowerCase() == widget.email.toLowerCase(),
      orElse: () => MockDatabase.instance.technicians.first,
    );
  }

  @override
  void initState() {
    super.initState();
    MockDatabase.instance.addListener(_onDbChanged);
    _initStatus();
  }

  void _onDbChanged() {
    if (mounted) {
      setState(() {
        _initStatus();
      });
    }
  }

  void _initStatus() {
    final tech = _currentTech;
    final status = tech.status;
    _techStatus = status == 'Active' ? 'Online' : status;
    if (_techStatus == 'Online') {
      _statusColor = const Color(0xFF0D9488);
    } else if (_techStatus == 'Busy') {
      _statusColor = Colors.orangeAccent;
    } else {
      _statusColor = Colors.grey;
    }
  }

  @override
  void dispose() {
    MockDatabase.instance.removeListener(_onDbChanged);
    super.dispose();
  }

  void _updateActiveJobStatus() {
    final ticket = _activePriorityTicket;
    if (ticket == null) return;

    int currentIndex = _statusSequence.indexOf(ticket.subStatus);
    if (currentIndex != -1 && currentIndex < _statusSequence.length - 1) {
      final nextSubStatus = _statusSequence[currentIndex + 1];
      final nextProgress = (currentIndex + 2) / _statusSequence.length;
      
      // Determine overall ticket status
      String nextStatus = 'In Progress';
      if (nextSubStatus == 'Ready for PickUp') {
        nextStatus = 'Completed';
      } else if (nextSubStatus == 'Delivered') {
        nextStatus = 'Delivered';
      }

      final updated = ticket.copyWith(
        subStatus: nextSubStatus,
        progress: nextProgress > 1.0 ? 1.0 : nextProgress,
        status: nextStatus,
      );
      
      MockDatabase.instance.updateTicket(updated);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Job status updated to $nextSubStatus!'),
          backgroundColor: const Color(0xFF0D9488),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  void _showStatusPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0F172A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Change Duty Status',
                style: GoogleFonts.outfit(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              _buildStatusRow(context, 'Online', const Color(0xFF0D9488)),
              _buildStatusRow(context, 'Busy', Colors.orangeAccent),
              _buildStatusRow(context, 'Offline', Colors.grey),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatusRow(BuildContext context, String status, Color color) {
    return ListTile(
      leading: Container(
        width: 12,
        height: 12,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      ),
      title: Text(
        status,
        style: GoogleFonts.inter(color: Colors.white, fontWeight: FontWeight.w600),
      ),
      onTap: () {
        final dbStatus = status == 'Online' ? 'Active' : status;
        MockDatabase.instance.updateTechnicianStatus(_currentTech.id, dbStatus);
        Navigator.pop(context);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          // Cyber glow blob
          Positioned(
            top: -80,
            left: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF0D9488).withOpacity(0.08),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF0D9488).withOpacity(0.08),
                    blurRadius: 100,
                    spreadRadius: 40,
                  )
                ],
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 16),
                    _buildHeader(),
                    const SizedBox(height: 20),
                    _buildQuickStats(),
                    const SizedBox(height: 24),

                    // Highlights / Active job card
                    Text(
                      'Active Priority Order',
                      style: GoogleFonts.outfit(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    _buildActiveJobCard(),

                    const SizedBox(height: 24),

                    // Tabs
                    _buildQueueTabs(),
                    const SizedBox(height: 16),

                    _activeTab == 0 ? _buildQueueTab() : _buildHistoryTab(),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFF0D9488), width: 2),
          ),
          child: CircleAvatar(
            radius: 24,
            backgroundImage: NetworkImage(_currentTech.imageUrl),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _currentTech.name,
                style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              GestureDetector(
                onTap: _showStatusPicker,
                child: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: _statusColor),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '$_techStatus - Tap to change',
                      style: GoogleFonts.inter(
                        color: const Color(0xFF94A3B8),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        IconButton(
          icon: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.logout_rounded, color: Colors.redAccent, size: 20),
          ),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const LoginScreen()),
            );
          },
        ),
      ],
    ).animate().fade(duration: 500.ms).slideY(begin: -0.1);
  }

  Widget _buildQuickStats() {
    return Row(
      children: [
        Expanded(child: _buildStatTile('Queue', _currentTech.activeJobs.toString(), const Color(0xFF0D9488))),
        const SizedBox(width: 12),
        Expanded(child: _buildStatTile('Finished', _currentTech.totalRepairs.toString(), Colors.greenAccent)),
        const SizedBox(width: 12),
        Expanded(child: _buildStatTile('Rating', '${(_currentTech.successRate * 5).toStringAsFixed(1)} ★', Colors.amberAccent)),
      ],
    ).animate().fade(duration: 500.ms, delay: 100.ms);
  }

  Widget _buildStatTile(String label, String value, Color color) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      opacity: 0.05,
      child: Column(
        children: [
          Text(value, style: GoogleFonts.outfit(color: color, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 2),
          Text(label, style: GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildActiveJobCard() {
    final ticket = _activePriorityTicket;
    if (ticket == null) {
      return GlassCard(
        opacity: 0.08,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Center(
            child: Text(
              'No active priority job assigned.',
              style: GoogleFonts.inter(color: Colors.white30),
            ),
          ),
        ),
      );
    }

    return GlassCard(
      opacity: 0.08,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'TICKET ${ticket.id}',
                style: GoogleFonts.outfit(color: const Color(0xFF2DD4BF), fontSize: 12, fontWeight: FontWeight.bold),
              ),
              Text(
                'Customer: ${ticket.customerName}',
                style: GoogleFonts.inter(color: const Color(0xFF94A3B8), fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '${ticket.brand} ${ticket.model}',
            style: GoogleFonts.outfit(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            'Reported Issue: ${ticket.issue}',
            style: GoogleFonts.inter(color: const Color(0xFF94A3B8), fontSize: 13, height: 1.4),
          ),
          const SizedBox(height: 16),

          // Progress indicator
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Repair Stage: ${ticket.subStatus}',
                    style: GoogleFonts.inter(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                  Text(
                    '${(ticket.progress * 100).toInt()}%',
                    style: GoogleFonts.inter(color: const Color(0xFF2DD4BF), fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: ticket.progress,
                  backgroundColor: Colors.white.withOpacity(0.05),
                  color: const Color(0xFF0D9488),
                  minHeight: 8,
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Status modifier
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    // Contact mock
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Simulating telephone call to customer: ${ticket.customerName}...'),
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    );
                  },
                  icon: const Icon(Icons.call, size: 16),
                  label: const Text('Call Customer'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: BorderSide(color: Colors.white.withOpacity(0.12)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GlowButton(
                  onPressed: ticket.subStatus == 'Delivered' ? null : _updateActiveJobStatus,
                  text: ticket.subStatus == 'Ready for PickUp' 
                      ? 'Mark as Delivered' 
                      : (ticket.subStatus == 'Delivered' ? 'Job Delivered' : 'Next Stage'),
                  icon: ticket.subStatus == 'Ready for PickUp' || ticket.subStatus == 'Delivered'
                      ? Icons.check_circle 
                      : Icons.double_arrow_rounded,
                  height: 48,
                  gradientColors: ticket.subStatus == 'Ready for PickUp' || ticket.subStatus == 'Delivered'
                      ? const [Colors.green, Colors.greenAccent]
                      : const [Color(0xFF0D9488), Color(0xFF0F766E)],
                  shadowColor: const Color(0xFF0D9488),
                ),
              ),
            ],
          )
        ],
      ),
    ).animate().fade(duration: 500.ms, delay: 200.ms);
  }

  Widget _buildQueueTabs() {
    final activeId = _selectedActiveTicketId;
    final queueCount = MockDatabase.instance.tickets.where(
      (t) => t.id != activeId && t.status != 'Completed' && t.status != 'Delivered'
    ).length;
    final historyCount = MockDatabase.instance.tickets.where(
      (t) => t.status == 'Completed' || t.status == 'Delivered'
    ).length;

    return Container(
      height: 44,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _activeTab = 0),
              child: Container(
                decoration: BoxDecoration(
                  color: _activeTab == 0 ? const Color(0xFF0D9488).withOpacity(0.15) : Colors.transparent,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    'Queue ($queueCount)',
                    style: GoogleFonts.inter(
                      color: _activeTab == 0 ? Colors.white : const Color(0xFF94A3B8),
                      fontWeight: _activeTab == 0 ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _activeTab = 1),
              child: Container(
                decoration: BoxDecoration(
                  color: _activeTab == 1 ? const Color(0xFF0D9488).withOpacity(0.15) : Colors.transparent,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    'History ($historyCount)',
                    style: GoogleFonts.inter(
                      color: _activeTab == 1 ? Colors.white : const Color(0xFF94A3B8),
                      fontWeight: _activeTab == 1 ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQueueTab() {
    final activeId = _selectedActiveTicketId;
    final list = MockDatabase.instance.tickets.where(
      (t) => t.id != activeId && t.status != 'Completed' && t.status != 'Delivered'
    ).toList();

    if (list.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Text(
            'Queue is empty.',
            style: GoogleFonts.inter(color: Colors.white30, fontSize: 13),
          ),
        ),
      );
    }

    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: list.length,
      separatorBuilder: (context, index) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final ticket = list[index];
        final priority = _getTicketPriority(ticket.id);
        final priorityColor = _getPriorityColor(priority);
        return GestureDetector(
          onTap: () {
            setState(() {
              _selectedActiveTicketId = ticket.id;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Swapped primary focus to ${ticket.brand} ${ticket.model}!'),
                backgroundColor: const Color(0xFF0D9488),
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            );
          },
          child: MouseRegion(
            cursor: SystemMouseCursors.click,
            child: GlassCard(
              padding: const EdgeInsets.all(16),
              opacity: 0.06,
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              ticket.id,
                              style: GoogleFonts.outfit(color: const Color(0xFF2DD4BF), fontSize: 11, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: priorityColor.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                priority,
                                style: TextStyle(color: priorityColor, fontSize: 9, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${ticket.brand} ${ticket.model}',
                          style: GoogleFonts.outfit(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          ticket.issue,
                          style: GoogleFonts.inter(color: const Color(0xFF94A3B8), fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFF2DD4BF), size: 16),
                ],
              ),
            ),
          ),
        );
      },
    ).animate().fade(duration: 400.ms);
  }

  Widget _buildHistoryTab() {
    final history = MockDatabase.instance.tickets.where(
      (t) => t.status == 'Completed' || t.status == 'Delivered'
    ).toList();

    if (history.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Text(
            'No service history.',
            style: GoogleFonts.inter(color: Colors.white30, fontSize: 13),
          ),
        ),
      );
    }

    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: history.length,
      separatorBuilder: (context, index) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final ticket = history[index];
        return GlassCard(
          padding: const EdgeInsets.all(16),
          opacity: 0.05,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          ticket.id,
                          style: GoogleFonts.outfit(color: const Color(0xFF64748B), fontSize: 11, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.greenAccent.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            ticket.status,
                            style: const TextStyle(color: Colors.greenAccent, fontSize: 9, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${ticket.brand} ${ticket.model}',
                      style: GoogleFonts.outfit(color: Colors.white.withOpacity(0.8), fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      ticket.issue,
                      style: GoogleFonts.inter(color: const Color(0xFF64748B), fontSize: 12),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.check_circle_outline_rounded, color: Colors.green, size: 20),
            ],
          ),
        );
      },
    ).animate().fade(duration: 400.ms);
  }
}

class _JobItem {
  final String id;
  final String device;
  final String issue;
  final String priority;
  final Color priorityColor;
  _JobItem(this.id, this.device, this.issue, this.priority, this.priorityColor);
}
