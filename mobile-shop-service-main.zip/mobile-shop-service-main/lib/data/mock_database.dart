import 'package:flutter/material.dart';
import '../models/customer.dart';
import '../models/repair_ticket.dart';
import '../models/technician.dart';

class MockDatabase extends ChangeNotifier {
  static final MockDatabase instance = MockDatabase._internal();

  factory MockDatabase() {
    return instance;
  }

  MockDatabase._internal() {
    _initializeData();
  }

  final List<Customer> _customers = [];
  final List<RepairTicket> _tickets = [];
  final List<Technician> _technicians = [];

  List<Customer> get customers => List.unmodifiable(_customers);
  List<RepairTicket> get tickets => List.unmodifiable(_tickets);
  List<Technician> get technicians => List.unmodifiable(_technicians);

  void _initializeData() {
    // Seed technicians
    _technicians.addAll([
      Technician(
        id: 'T-001',
        name: 'John Miller',
        role: 'Senior Hardware Engineer',
        email: 'john.miller@mobitracker.com',
        phone: '+1 (555) 021-4400',
        imageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=256',
        status: 'Active',
        successRate: 0.98,
        totalRepairs: 284,
        activeJobs: 2,
        joinDate: 'Jan 2022',
        specializations: ['MacBook', 'iPhone', 'Windows Laptops'],
        repairNotes: [
          RepairNote(
            id: 'RN-001',
            ticketId: '#1093',
            deviceName: 'MacBook Pro 16"',
            content: 'Confirmed motherboard power rail failure at U8300. Ordered replacement component. ETA 1 day. Customer notified.',
            timestamp: DateTime.now().subtract(const Duration(hours: 3)),
            technicianId: 'T-001',
          ),
          RepairNote(
            id: 'RN-002',
            ticketId: '#1095',
            deviceName: 'Sony PlayStation 5',
            content: 'Fan bearing worn. Thermal paste dried out. Replacement fan installed. Running diagnostics — all temps normal.',
            timestamp: DateTime.now().subtract(const Duration(hours: 6)),
            technicianId: 'T-001',
          ),
        ],
        dailyTasks: [
          DailyTask(
            id: 'DT-001',
            ticketId: '#1093',
            customerName: 'Lisa Vance',
            deviceName: 'MacBook Pro 16"',
            taskDescription: 'Complete motherboard diagnostic & replace power IC chip',
            priority: 'High',
            isCompleted: false,
            scheduledTime: DateTime.now().copyWith(hour: 9, minute: 0),
          ),
          DailyTask(
            id: 'DT-002',
            ticketId: '#1095',
            customerName: 'Emily Watson',
            deviceName: 'Sony PlayStation 5',
            taskDescription: 'Final stress test after fan replacement — confirm stable temperatures',
            priority: 'Medium',
            isCompleted: true,
            scheduledTime: DateTime.now().copyWith(hour: 11, minute: 30),
          ),
          DailyTask(
            id: 'DT-003',
            ticketId: '#1094',
            customerName: 'Lisa Vance',
            deviceName: 'iPhone 14 Pro',
            taskDescription: 'Install replacement battery cell & run iOS battery calibration',
            priority: 'Medium',
            isCompleted: false,
            scheduledTime: DateTime.now().copyWith(hour: 14, minute: 0),
          ),
        ],
      ),
      Technician(
        id: 'T-002',
        name: 'Alex Carter',
        role: 'AC & Appliance Specialist',
        email: 'alex.carter@mobitracker.com',
        phone: '+1 (555) 033-9900',
        imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=256',
        status: 'Active',
        successRate: 0.92,
        totalRepairs: 198,
        activeJobs: 1,
        joinDate: 'Mar 2022',
        specializations: ['AC Units', 'Refrigerators', 'Washing Machines'],
        repairNotes: [
          RepairNote(
            id: 'RN-003',
            ticketId: '#1097',
            deviceName: 'Nintendo Switch Lite',
            content: 'Left joycon hall-effect sensor completely worn. Ordered OEM replacement. Original drift confirmed on diagnostics.',
            timestamp: DateTime.now().subtract(const Duration(hours: 1)),
            technicianId: 'T-002',
          ),
        ],
        dailyTasks: [
          DailyTask(
            id: 'DT-004',
            ticketId: '#1097',
            customerName: 'Robert Chen',
            deviceName: 'Nintendo Switch Lite',
            taskDescription: 'Replace both joycon analog sticks with hall-effect sensors',
            priority: 'Low',
            isCompleted: false,
            scheduledTime: DateTime.now().copyWith(hour: 10, minute: 0),
          ),
          DailyTask(
            id: 'DT-005',
            ticketId: '#2001',
            customerName: 'Walk-in Customer',
            deviceName: 'Samsung Split AC 1.5T',
            taskDescription: 'Inspect compressor — reported no cooling after power surge',
            priority: 'High',
            isCompleted: false,
            scheduledTime: DateTime.now().copyWith(hour: 13, minute: 0),
          ),
        ],
      ),
      Technician(
        id: 'T-003',
        name: 'Michael Vance',
        role: 'Electronics & PCB Repair',
        email: 'michael.vance@mobitracker.com',
        phone: '+1 (555) 044-1221',
        imageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=256',
        status: 'Busy',
        successRate: 0.95,
        totalRepairs: 312,
        activeJobs: 3,
        joinDate: 'Sep 2021',
        specializations: ['PCB Repair', 'TVs', 'Gaming Consoles'],
        repairNotes: [],
        dailyTasks: [
          DailyTask(
            id: 'DT-006',
            ticketId: '#2002',
            customerName: 'Walk-in Customer',
            deviceName: 'LG OLED 55" TV',
            taskDescription: 'Diagnose backlight failure — check T-CON board and MOSFET drivers',
            priority: 'High',
            isCompleted: false,
            scheduledTime: DateTime.now().copyWith(hour: 9, minute: 30),
          ),
          DailyTask(
            id: 'DT-007',
            ticketId: '#2003',
            customerName: 'Walk-in Customer',
            deviceName: 'Xbox Series X',
            taskDescription: 'Replace faulty HDMI port after liquid damage',
            priority: 'Medium',
            isCompleted: true,
            scheduledTime: DateTime.now().copyWith(hour: 12, minute: 0),
          ),
        ],
      ),
      Technician(
        id: 'T-004',
        name: 'Samantha Reed',
        role: 'Smartphones & Tablets',
        email: 'samantha.reed@mobitracker.com',
        phone: '+1 (555) 055-3344',
        imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=256',
        status: 'Offline',
        successRate: 0.89,
        totalRepairs: 156,
        activeJobs: 0,
        joinDate: 'Jun 2023',
        specializations: ['Samsung', 'Pixel', 'iPad', 'OnePlus'],
        repairNotes: [],
        dailyTasks: [],
      ),
    ]);

    // Seed initial customers

    _customers.addAll([
      Customer(
        id: 'C-101',
        name: 'Lisa Vance',
        email: 'customer.lisa@gmail.com', // Aligned with Lisa's test credentials
        phone: '+1 (555) 019-2834',
      ),
      Customer(
        id: 'C-102',
        name: 'David Miller',
        email: 'david.m@example.com',
        phone: '+1 (555) 014-9922',
      ),
      Customer(
        id: 'C-103',
        name: 'Robert Chen',
        email: 'robert.chen@example.com',
        phone: '+1 (555) 017-3311',
      ),
      Customer(
        id: 'C-104',
        name: 'Emily Watson',
        email: 'emily.w@example.com',
        phone: '+1 (555) 012-7788',
      ),
    ]);

    // Seed initial tickets
    _tickets.addAll([
      RepairTicket(
        id: '#1093',
        customerId: 'C-101',
        customerName: 'Lisa Vance',
        customerPhone: '+1 (555) 019-2834',
        brand: 'Apple',
        model: 'MacBook Pro 16"',
        imei: '358291048201948',
        issue: 'Kernel panic on startup, motherboard power supply failure suspected.',
        status: 'In Progress',
        subStatus: 'Diagnosing',
        progress: 0.4,
        serviceDate: DateTime.now().subtract(const Duration(days: 1)),
        deliveryDate: DateTime.now().add(const Duration(days: 2)),
        warranty: '6 Months',
        techName: 'John Miller',
      ),
      RepairTicket(
        id: '#1094',
        customerId: 'C-101',
        customerName: 'Lisa Vance',
        customerPhone: '+1 (555) 019-2834',
        brand: 'Apple',
        model: 'iPhone 14 Pro',
        imei: '864810052910482',
        issue: 'Battery Degradation replacement',
        status: 'Pending',
        subStatus: 'Received',
        progress: 0.2,
        serviceDate: DateTime.now().subtract(const Duration(hours: 12)),
        deliveryDate: DateTime.now().add(const Duration(days: 1)),
        warranty: '3 Months',
        techName: 'Assigning Tech...',
      ),
      RepairTicket(
        id: '#1095',
        customerId: 'C-104',
        customerName: 'Emily Watson',
        customerPhone: '+1 (555) 012-7788',
        brand: 'Sony',
        model: 'PlayStation 5',
        imei: 'N/A - PS5-882901',
        issue: 'Overheating & fan replacement',
        status: 'In Progress',
        subStatus: 'Repairing',
        progress: 0.6,
        serviceDate: DateTime.now().subtract(const Duration(days: 2)),
        deliveryDate: DateTime.now().add(const Duration(days: 1)),
        warranty: 'None',
        techName: 'John Miller',
      ),
      RepairTicket(
        id: '#1097',
        customerId: 'C-103',
        customerName: 'Robert Chen',
        customerPhone: '+1 (555) 017-3311',
        brand: 'Nintendo',
        model: 'Switch Lite',
        imei: 'N/A - SW-992019',
        issue: 'Joycon Drift joystick swap',
        status: 'Pending',
        subStatus: 'Received',
        progress: 0.2,
        serviceDate: DateTime.now(),
        deliveryDate: DateTime.now().add(const Duration(days: 3)),
        warranty: 'None',
        techName: 'Assigning Tech...',
      ),
      RepairTicket(
        id: '#9087',
        customerId: 'C-101',
        customerName: 'Lisa Vance',
        customerPhone: '+1 (555) 019-2834',
        brand: 'Apple',
        model: 'iPhone 13 Pro Screen Fix',
        imei: '351984029482019',
        issue: 'Cracked Screen',
        status: 'Completed',
        subStatus: 'Ready for PickUp',
        progress: 1.0,
        serviceDate: DateTime.now().subtract(const Duration(days: 30)),
        deliveryDate: DateTime.now().subtract(const Duration(days: 29)),
        warranty: '12 Months',
        techName: 'John Miller',
      ),
      RepairTicket(
        id: '#8865',
        customerId: 'C-103',
        customerName: 'Robert Chen',
        customerPhone: '+1 (555) 017-3311',
        brand: 'Sony',
        model: 'PlayStation 5 Cleaning',
        imei: 'N/A - PS5-110022',
        issue: 'Dust buildup & noise',
        status: 'Delivered',
        subStatus: 'Delivered',
        progress: 1.0,
        serviceDate: DateTime.now().subtract(const Duration(days: 60)),
        deliveryDate: DateTime.now().subtract(const Duration(days: 59)),
        warranty: 'None',
        techName: 'John Miller',
      ),
    ]);
  }

  // --- Customer Operations ---
  void addCustomer(Customer customer) {
    _customers.add(customer);
    notifyListeners();
  }

  void editCustomer(Customer updatedCustomer) {
    final index = _customers.indexWhere((c) => c.id == updatedCustomer.id);
    if (index != -1) {
      _customers[index] = updatedCustomer;
      notifyListeners();
    }
  }

  void deleteCustomer(String id) {
    // 1. Get all ticket IDs associated with this customer
    final customerTicketIds = _tickets
        .where((t) => t.customerId == id)
        .map((t) => t.id)
        .toList();

    // 2. Remove all those tickets
    _tickets.removeWhere((t) => t.customerId == id);

    // 3. Remove corresponding daily tasks and repair notes from technicians
    for (int i = 0; i < _technicians.length; i++) {
      final tech = _technicians[i];
      final updatedTasks = tech.dailyTasks
          .where((task) => !customerTicketIds.contains(task.ticketId))
          .toList();
      final updatedNotes = tech.repairNotes
          .where((note) => !customerTicketIds.contains(note.ticketId))
          .toList();
      _technicians[i] = tech.copyWith(
        dailyTasks: updatedTasks,
        repairNotes: updatedNotes,
      );
    }

    // 4. Remove the customer
    _customers.removeWhere((c) => c.id == id);

    // 5. Update active jobs count
    _updateActiveJobsCount();

    notifyListeners();
  }

  // --- Repair Ticket Operations ---
  void addTicket(RepairTicket ticket) {
    _tickets.insert(0, ticket); // Add to top of list
    _updateActiveJobsCount();
    notifyListeners();
  }

  void updateTicket(RepairTicket updatedTicket) {
    final index = _tickets.indexWhere((t) => t.id == updatedTicket.id);
    if (index != -1) {
      _tickets[index] = updatedTicket;
      _updateActiveJobsCount();
      notifyListeners();
    }
  }

  void deleteTicket(String id) {
    // 1. Remove the ticket
    _tickets.removeWhere((t) => t.id == id);

    // 2. Remove corresponding daily tasks and repair notes from all technicians
    for (int i = 0; i < _technicians.length; i++) {
      final tech = _technicians[i];
      final updatedTasks = tech.dailyTasks.where((task) => task.ticketId != id).toList();
      final updatedNotes = tech.repairNotes.where((note) => note.ticketId != id).toList();
      _technicians[i] = tech.copyWith(
        dailyTasks: updatedTasks,
        repairNotes: updatedNotes,
      );
    }

    // 3. Update active jobs count
    _updateActiveJobsCount();

    notifyListeners();
  }

  void _updateActiveJobsCount() {
    for (int i = 0; i < _technicians.length; i++) {
      final tech = _technicians[i];
      final count = _tickets.where((t) => t.techName == tech.name && t.status != 'Delivered').length;
      _technicians[i] = tech.copyWith(activeJobs: count);
    }
  }

  // Helper getters
  List<RepairTicket> getTicketsForCustomer(String customerId) {
    return _tickets.where((t) => t.customerId == customerId).toList();
  }

  List<RepairTicket> getActiveTicketsForCustomer(String customerId) {
    return _tickets
        .where((t) => t.customerId == customerId && t.status != 'Delivered')
        .toList();
  }

  List<RepairTicket> getPastTicketsForCustomer(String customerId) {
    return _tickets
        .where((t) => t.customerId == customerId && t.status == 'Delivered')
        .toList();
  }

  // --- Technician Operations ---
  void addTechnician(Technician technician) {
    _technicians.add(technician);
    notifyListeners();
  }

  void editTechnician(Technician updatedTech) {
    final index = _technicians.indexWhere((t) => t.id == updatedTech.id);
    if (index != -1) {
      _technicians[index] = updatedTech;
      notifyListeners();
    }
  }

  void deleteTechnician(String id) {
    _technicians.removeWhere((t) => t.id == id);
    _updateActiveJobsCount();
    notifyListeners();
  }

  void updateTechnicianStatus(String techId, String newStatus) {
    final index = _technicians.indexWhere((t) => t.id == techId);
    if (index != -1) {
      _technicians[index] = _technicians[index].copyWith(status: newStatus);
      notifyListeners();
    }
  }

  /// Assigns a technician to a repair ticket by name
  void assignTechnicianToTicket(String ticketId, String techName) {
    final index = _tickets.indexWhere((t) => t.id == ticketId);
    if (index != -1) {
      _tickets[index] = _tickets[index].copyWith(techName: techName);
      _updateActiveJobsCount();
      notifyListeners();
    }
  }

  /// Adds a repair note for a technician
  void addRepairNote(String techId, RepairNote note) {
    final index = _technicians.indexWhere((t) => t.id == techId);
    if (index != -1) {
      final updated = List<RepairNote>.from(_technicians[index].repairNotes)
        ..insert(0, note);
      _technicians[index] = _technicians[index].copyWith(repairNotes: updated);
      notifyListeners();
    }
  }

  /// Toggles daily task completion
  void toggleDailyTask(String techId, String taskId) {
    final techIndex = _technicians.indexWhere((t) => t.id == techId);
    if (techIndex != -1) {
      final tasks = List<DailyTask>.from(_technicians[techIndex].dailyTasks);
      final taskIndex = tasks.indexWhere((dt) => dt.id == taskId);
      if (taskIndex != -1) {
        tasks[taskIndex] = tasks[taskIndex].copyWith(
          isCompleted: !tasks[taskIndex].isCompleted,
        );
        _technicians[techIndex] =
            _technicians[techIndex].copyWith(dailyTasks: tasks);
        notifyListeners();
      }
    }
  }

  /// Adds a new daily task to a technician's list
  void addDailyTask(String techId, DailyTask task) {
    final index = _technicians.indexWhere((t) => t.id == techId);
    if (index != -1) {
      final updated = List<DailyTask>.from(_technicians[index].dailyTasks)
        ..add(task);
      _technicians[index] = _technicians[index].copyWith(dailyTasks: updated);
      notifyListeners();
    }
  }

  Technician? getTechnicianById(String id) {
    try {
      return _technicians.firstWhere((t) => t.id == id);
    } catch (_) {
      return null;
    }
  }

  List<RepairTicket> getTicketsForTechnician(String techName) {
    return _tickets.where((t) => t.techName == techName).toList();
  }
}
