class RepairTicket {
  final String id;
  final String customerId;
  final String customerName;
  final String customerPhone;
  final String brand;
  final String model;
  final String imei;
  final String issue;
  final String status; // 'Pending', 'In Progress', 'Completed', 'Delivered'
  final String subStatus; // 'Received', 'Diagnosing', 'Repairing', 'Testing', 'Ready for PickUp', 'Delivered'
  final double progress; // 0.0 to 1.0
  final DateTime serviceDate;
  final DateTime deliveryDate;
  final String warranty; // e.g. 'None', '3 Months', '6 Months', '12 Months'
  final String techName; // e.g. 'John Miller' or 'Assigning Tech...'

  RepairTicket({
    required this.id,
    required this.customerId,
    required this.customerName,
    required this.customerPhone,
    required this.brand,
    required this.model,
    required this.imei,
    required this.issue,
    required this.status,
    required this.subStatus,
    required this.progress,
    required this.serviceDate,
    required this.deliveryDate,
    required this.warranty,
    required this.techName,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerId': customerId,
      'customerName': customerName,
      'customerPhone': customerPhone,
      'brand': brand,
      'model': model,
      'imei': imei,
      'issue': issue,
      'status': status,
      'subStatus': subStatus,
      'progress': progress,
      'serviceDate': serviceDate.toIso8601String(),
      'deliveryDate': deliveryDate.toIso8601String(),
      'warranty': warranty,
      'techName': techName,
    };
  }

  factory RepairTicket.fromMap(Map<String, dynamic> map) {
    return RepairTicket(
      id: map['id'] ?? '',
      customerId: map['customerId'] ?? '',
      customerName: map['customerName'] ?? '',
      customerPhone: map['customerPhone'] ?? '',
      brand: map['brand'] ?? '',
      model: map['model'] ?? '',
      imei: map['imei'] ?? '',
      issue: map['issue'] ?? '',
      status: map['status'] ?? 'Pending',
      subStatus: map['subStatus'] ?? 'Received',
      progress: (map['progress'] as num?)?.toDouble() ?? 0.0,
      serviceDate: DateTime.parse(map['serviceDate'] ?? DateTime.now().toIso8601String()),
      deliveryDate: DateTime.parse(map['deliveryDate'] ?? DateTime.now().add(const Duration(days: 3)).toIso8601String()),
      warranty: map['warranty'] ?? 'None',
      techName: map['techName'] ?? 'Assigning Tech...',
    );
  }

  RepairTicket copyWith({
    String? id,
    String? customerId,
    String? customerName,
    String? customerPhone,
    String? brand,
    String? model,
    String? imei,
    String? issue,
    String? status,
    String? subStatus,
    double? progress,
    DateTime? serviceDate,
    DateTime? deliveryDate,
    String? warranty,
    String? techName,
  }) {
    return RepairTicket(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      customerName: customerName ?? this.customerName,
      customerPhone: customerPhone ?? this.customerPhone,
      brand: brand ?? this.brand,
      model: model ?? this.model,
      imei: imei ?? this.imei,
      issue: issue ?? this.issue,
      status: status ?? this.status,
      subStatus: subStatus ?? this.subStatus,
      progress: progress ?? this.progress,
      serviceDate: serviceDate ?? this.serviceDate,
      deliveryDate: deliveryDate ?? this.deliveryDate,
      warranty: warranty ?? this.warranty,
      techName: techName ?? this.techName,
    );
  }
}
