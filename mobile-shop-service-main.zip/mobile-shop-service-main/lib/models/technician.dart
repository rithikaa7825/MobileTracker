class Technician {
  final String id;
  final String name;
  final String role;
  final String email;
  final String phone;
  final String imageUrl;
  final String status; // 'Active', 'Busy', 'Offline'
  final double successRate; // 0.0 - 1.0
  final int totalRepairs;
  final int activeJobs;
  final String joinDate;
  final List<String> specializations;
  final List<RepairNote> repairNotes;
  final List<DailyTask> dailyTasks;

  Technician({
    required this.id,
    required this.name,
    required this.role,
    required this.email,
    required this.phone,
    required this.imageUrl,
    required this.status,
    required this.successRate,
    required this.totalRepairs,
    required this.activeJobs,
    required this.joinDate,
    this.specializations = const [],
    this.repairNotes = const [],
    this.dailyTasks = const [],
  });

  Technician copyWith({
    String? id,
    String? name,
    String? role,
    String? email,
    String? phone,
    String? imageUrl,
    String? status,
    double? successRate,
    int? totalRepairs,
    int? activeJobs,
    String? joinDate,
    List<String>? specializations,
    List<RepairNote>? repairNotes,
    List<DailyTask>? dailyTasks,
  }) {
    return Technician(
      id: id ?? this.id,
      name: name ?? this.name,
      role: role ?? this.role,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      imageUrl: imageUrl ?? this.imageUrl,
      status: status ?? this.status,
      successRate: successRate ?? this.successRate,
      totalRepairs: totalRepairs ?? this.totalRepairs,
      activeJobs: activeJobs ?? this.activeJobs,
      joinDate: joinDate ?? this.joinDate,
      specializations: specializations ?? this.specializations,
      repairNotes: repairNotes ?? this.repairNotes,
      dailyTasks: dailyTasks ?? this.dailyTasks,
    );
  }
}

class RepairNote {
  final String id;
  final String ticketId;
  final String deviceName;
  final String content;
  final DateTime timestamp;
  final String technicianId;

  RepairNote({
    required this.id,
    required this.ticketId,
    required this.deviceName,
    required this.content,
    required this.timestamp,
    required this.technicianId,
  });
}

class DailyTask {
  final String id;
  final String ticketId;
  final String customerName;
  final String deviceName;
  final String taskDescription;
  final String priority; // 'High', 'Medium', 'Low'
  final bool isCompleted;
  final DateTime scheduledTime;

  DailyTask({
    required this.id,
    required this.ticketId,
    required this.customerName,
    required this.deviceName,
    required this.taskDescription,
    required this.priority,
    required this.isCompleted,
    required this.scheduledTime,
  });

  DailyTask copyWith({
    String? id,
    String? ticketId,
    String? customerName,
    String? deviceName,
    String? taskDescription,
    String? priority,
    bool? isCompleted,
    DateTime? scheduledTime,
  }) {
    return DailyTask(
      id: id ?? this.id,
      ticketId: ticketId ?? this.ticketId,
      customerName: customerName ?? this.customerName,
      deviceName: deviceName ?? this.deviceName,
      taskDescription: taskDescription ?? this.taskDescription,
      priority: priority ?? this.priority,
      isCompleted: isCompleted ?? this.isCompleted,
      scheduledTime: scheduledTime ?? this.scheduledTime,
    );
  }
}
