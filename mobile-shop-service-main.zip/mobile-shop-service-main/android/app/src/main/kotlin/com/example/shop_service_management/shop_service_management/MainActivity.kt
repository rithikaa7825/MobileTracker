package com.example.shop_service_management.shop_service_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
