import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shop_service_management/main.dart';

void main() {
  testWidgets('Welcome screen and navigation to login screen test', (WidgetTester tester) async {
    // Set a spacious screen size to avoid any horizontal/vertical overflows in tests
    final TestWidgetsFlutterBinding binding = TestWidgetsFlutterBinding.ensureInitialized();
    await binding.setSurfaceSize(const Size(800, 1200));

    // Build our app and trigger a frame.
    await tester.pumpWidget(const MyApp());

    // Verify that the welcome screen elements are shown.
    expect(find.text('MobiTracker'), findsOneWidget);
    expect(find.text('Get Started'), findsOneWidget);

    // Tap the 'Get Started' button.
    await tester.tap(find.text('Get Started'));
    
    // Trigger navigation and let animation complete.
    await tester.pumpAndSettle();

    // Verify we are on the Login screen by looking for text unique to it.
    expect(find.text('Sign In'), findsOneWidget);

    // Reset surface size
    await binding.setSurfaceSize(null);
  });
}
