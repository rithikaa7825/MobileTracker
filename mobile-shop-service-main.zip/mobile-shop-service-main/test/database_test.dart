import 'package:flutter_test/flutter_test.dart';
import 'package:shop_service_management/data/mock_database.dart';
import 'package:shop_service_management/models/customer.dart';
import 'package:shop_service_management/models/repair_ticket.dart';
import 'package:shop_service_management/models/technician.dart';

void main() {
  group('MockDatabase Cascading Delete Tests', () {
    late MockDatabase db;

    setUp(() {
      db = MockDatabase.instance;
      // Reset database state if there's any state persistence/shared instance
      // Note: Since MockDatabase is a singleton, let's make sure it's initialized
    });

    test('Customer deletion cascades to tickets, daily tasks, and repair notes', () {
      // 1. Find a customer in the initial database state
      final customer = db.customers.first;
      final customerId = customer.id;

      // Ensure they have associated tickets
      final ticketsBefore = db.getTicketsForCustomer(customerId);
      expect(ticketsBefore.isNotEmpty, true);

      // Collect the ticket IDs
      final ticketIds = ticketsBefore.map((t) => t.id).toList();

      // Ensure some technicians have daily tasks or notes referencing these tickets
      bool hasAssociatedTasksOrNotes = false;
      for (final tech in db.technicians) {
        final tasks = tech.dailyTasks.where((task) => ticketIds.contains(task.ticketId));
        final notes = tech.repairNotes.where((note) => ticketIds.contains(note.ticketId));
        if (tasks.isNotEmpty || notes.isNotEmpty) {
          hasAssociatedTasksOrNotes = true;
          break;
        }
      }
      expect(hasAssociatedTasksOrNotes, true);

      // 2. Perform cascade delete
      db.deleteCustomer(customerId);

      // 3. Verify customer is deleted
      expect(db.customers.any((c) => c.id == customerId), false);

      // 4. Verify all associated tickets are deleted
      expect(db.getTicketsForCustomer(customerId).isEmpty, true);

      // 5. Verify no technician has daily tasks or notes referencing the deleted tickets
      for (final tech in db.technicians) {
        final remainingTasks = tech.dailyTasks.where((task) => ticketIds.contains(task.ticketId));
        final remainingNotes = tech.repairNotes.where((note) => ticketIds.contains(note.ticketId));
        expect(remainingTasks.isEmpty, true);
        expect(remainingNotes.isEmpty, true);
      }
    });

    test('Ticket deletion cascades to daily tasks, repair notes, and updates active jobs count', () {
      // 1. Find an active ticket (not 'Delivered')
      final ticket = db.tickets.firstWhere((t) => t.status != 'Delivered');
      final ticketId = ticket.id;
      final techName = ticket.techName;

      // Find the technician assigned to this ticket
      final technician = db.technicians.firstWhere((tech) => tech.name == techName);
      final initialActiveJobs = technician.activeJobs;

      // Add a dummy task and note for this ticket if not already present
      // To test deletion specifically
      
      // 2. Delete the ticket
      db.deleteTicket(ticketId);

      // 3. Verify ticket is deleted
      expect(db.tickets.any((t) => t.id == ticketId), false);

      // 4. Verify tasks and notes in technicians are deleted
      for (final tech in db.technicians) {
        final remainingTasks = tech.dailyTasks.where((task) => task.ticketId == ticketId);
        final remainingNotes = tech.repairNotes.where((note) => note.ticketId == ticketId);
        expect(remainingTasks.isEmpty, true);
        expect(remainingNotes.isEmpty, true);
      }

      // 5. Verify technician active job count is decremented/updated correctly
      final updatedTechnician = db.technicians.firstWhere((tech) => tech.name == techName);
      expect(updatedTechnician.activeJobs, lessThanOrEqualTo(initialActiveJobs));
    });
  });
}
